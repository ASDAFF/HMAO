<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Новости");
?>Главная страница раздела "Новости"<br><?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>