<?
require($_SERVER['DOCUMENT_ROOT'].'/bitrix/header.php');
$APPLICATION->SetTitle("Главная");
?>Страница "Общая информация"
<?
require($_SERVER['DOCUMENT_ROOT'].'/bitrix/footer.php');
?>