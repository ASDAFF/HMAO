<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Органы управления образованием");
?>Страница "Органы управления образованием"<br><?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>