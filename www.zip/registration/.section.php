<?
$sSectionName = "Регистрация";
$arDirProperties = Array(

);
?>