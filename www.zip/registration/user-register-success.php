<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Успешная регистрация пользователя");
?>Вы успешно зарегистрировались в системе. На указанный в форме e-mail придет запрос на подтверждение регистрации. После этого вы сожете осуществить вход в систему под своей учётной записью.<br><?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>