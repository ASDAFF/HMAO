<?
$aMenuLinks = Array(
	Array(
		"Регистрация абитуриента", 
		"abiturient-registration.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Регистрация организации", 
		"edu-organization-register.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Успешная регистрация пользователя", 
		"/registration/user-register-success.php", 
		Array(), 
		Array(), 
		"" 
	)
);
?>