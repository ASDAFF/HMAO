<?php

class SPOBaseEducation extends SPODictionary
{
	const BASIC = 1;
	const SECONDARY = 2;

	protected static $values = array(
		self::BASIC => 'На базе основного общего образования',
		self::SECONDARY => 'На базе среднего (полного) общего образования',
	);

}