<?php

class SPOStudyMode extends SPODictionary
{
	const INTRAMURAL = 1;
	const EXTRAMURAL = 2;
	const MIXED = 3;

	protected static $values = array(
		self::INTRAMURAL => 'Очная форма обучения',
		self::EXTRAMURAL => 'Заочная форма обучения',
		self::MIXED => 'Очно-заочная форма обучения',
	);

}