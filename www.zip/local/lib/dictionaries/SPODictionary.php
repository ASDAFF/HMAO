<?php

class SPODictionary
{

	protected static $values = array();

	public static function getValue($code)
	{
		if (array_key_exists($code, static::$values))
			return static::$values[$code];

		return null;
	}

	private static function getClassConstants() {
		$oClass = new ReflectionClass(__CLASS__);
		return $oClass->getConstants();
	}

	public static function isDefined($code)
	{
		if (array_key_exists($code, static::getClassConstants()))
			return true;

		return false;
	}

}