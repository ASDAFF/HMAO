<?php

class SPOApplicationStatus extends SPODictionary
{
	const CREATED = 1;
	const ACCEPTED = 2;
	const DECLINED = 3;
	const DELETED = 4;

	protected static $values = array(
		self::CREATED => 'На рассмотрении',
		self::ACCEPTED => 'Принято',
		self::DECLINED => 'Отклонено',
		self::DELETED => 'Удалено',
	);

}