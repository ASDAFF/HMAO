<?php

use Doctrine\ORM\Mapping\Entity;
use Doctrine\ORM\Mapping\Column;
use Doctrine\ORM\Mapping\GeneratedValue;
use Doctrine\ORM\Mapping\Id;
use Doctrine\Common\Collections\ArrayCollection;
use Symfony\Component\Validator\Constraints as Assert;


/**
 * @Entity(repositoryClass="ApplicationRepository")
 * @Table(name="spo_application")
 *
 * Class Application - заявка абитуриента
 */
class Application
{

    /**
     * @var integer
     * @Column(name="application_id", type="integer", nullable=false, unique=true)
     * @Id
     * @GeneratedValue
     */
    private $applicationId;

    /**
     * @var integer
     * @Column(name="user_id", type="integer", nullable=false)
     */
    private $userId;

    /**
     * @var integer
     * @Column(name="organization_id", type="integer", nullable=false)
     */
    private $organizationId;

    /**
     * @var \DateTime
     * @Column(name="application_creation_date", type="datetime", nullable=false)
     */
    private $applicationCreationDate;

    /**
     * @var integer
     * @Column(name="organization_specialty_id", type="integer", nullable=false)
     */
    private $organizationSpecialtyId;

	/**
	 * @var integer
	 * @Column(name="application_status", type="integer", nullable=false)
	 */
	private $applicationStatus;


	/************************* Relations *************************/

	/**
	 * @OneToOne(targetEntity="OrganizationSpecialty")
	 * @JoinColumn(name="organization_specialty_id", referencedColumnName="organization_specialty_id")
	 */
	private $organizationSpecialty;

	/**
	 * @ManyToOne(targetEntity="BitrixUser")
	 * @JoinColumn(name="user_id", referencedColumnName="id")
	 */
	private $user;

	/************************* Getters/Setters *************************/

	public function getId()
	{
		return $this->applicationId;
	}

	public function getStatus()
	{
		return $this->applicationStatus;
	}

	public function getCreationDate()
	{
		return $this->applicationCreationDate->format('d-m-Y');
	}

	/**
	 * @return OrganizationSpecialty
	 */
	public function getOrganizationSpecialty()
	{
		return $this->organizationSpecialty;
	}

	/**
	 * @return BitrixUser
	 */
	public function getBitrixUser()
	{
		return $this->user;
	}

	public function setApplicationStatus($status)
	{
		$this->applicationStatus = $status;
	}

}
