<?php

use Doctrine\ORM\Mapping\Entity;
use Doctrine\ORM\Mapping\Column;
use Doctrine\ORM\Mapping\GeneratedValue;
use Doctrine\ORM\Mapping\Id;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Class BitrixUser
 * @Entity
 * @Table(name="b_user")
 */
class BitrixUser
{
	/**
	 * @Column(name="id")
	 * @Id
	 */
	private $id;

	/**
	 * @Column(name="login")
	 */
	private $login;

	/**
	 * @Column(name="email")
	 */
	private $email;

	/**
	 * @Column(name="name")
	 */
	private $name;

	/**
	 * @Column(name="last_name")
	 */
	private $lastName;

	/**
	 * @Column(name="confirm_code")
	 */
	private $confirmCode;

	/**
	 * @Column(name="second_name")
	 */
	private $secondName;

	public function getEmail()
	{
		return $this->email;
	}

	public function getFullName()
	{
		return $this->lastName . ' ' . $this->name . ' ' . $this->secondName;
	}
}
