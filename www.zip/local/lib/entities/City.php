<?php

use Doctrine\ORM\Mapping\Entity;
use Doctrine\ORM\Mapping\Column;
use Doctrine\ORM\Mapping\GeneratedValue;
use Doctrine\ORM\Mapping\Id;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @Entity
 * @Table(name="spo_city")
 */
class City
{
	/**
	 * @var integer
	 *
	 * @Column(name="city_id", type="integer", nullable=false)
	 * @Id
	 * @GeneratedValue
	 */
	private $cityId;

	/**
	 * @var string
	 *
	 * @Column(name="city_name", type="string", length=255, nullable=false)
	 */
	private $cityName;

	/**
	 * @ManyToOne(targetEntity="Region")
	 * @JoinColumns({
	 *   @JoinColumn(name="region_id", referencedColumnName="region_id")
	 * })
	 */
	private $region;


}
