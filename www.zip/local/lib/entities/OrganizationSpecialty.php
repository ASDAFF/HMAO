<?php

use Doctrine\ORM\Mapping\Entity;
use Doctrine\ORM\Mapping\Column;
use Doctrine\ORM\Mapping\GeneratedValue;
use Doctrine\ORM\Mapping\Id;
use Doctrine\Common\Collections\ArrayCollection;
use Symfony\Component\Validator\Constraints as Assert;


/**
 * @Entity
 * @Table(name="spo_organization_specialty")
 *
 * Class OrganizationSpecialty - направления  подготовки организации
 * (специальность, форма обучения, базовое образование)
 */
class OrganizationSpecialty
{

    /**
     * @var integer
     * @Column(name="organization_specialty_id", type="integer", nullable=false, unique=true)
     * @Id
     * @GeneratedValue
     */
    private $organizationSpecialtyId;

	/**
	 * @var integer
	 * @Column(name="organization_id", type="integer", nullable=false)
	 */
	private $organizationId;

	/**
	 * @var integer
	 * @Column(name="specialty_id", type="integer", nullable=false)
	 */
	private $specialtyId;

	/**
	 * @var integer
	 * @Column(name="organization_specialty_study_mode", type="integer", nullable=false)
	 */
	private $studyMode;

	/**
	 * @var integer
	 * @Column(name="organization_specialty_base_education", type="integer", nullable=false)
	 */
	private $baseEducation;

	/**
	 * @var integer
	 * @Column(name="organization_specialty_status", type="integer", nullable=false)
	 */
	private $status;


	/************************* Relations *************************/

	/**
	 * @OneToOne(targetEntity="Specialty")
	 * @JoinColumns({
	 *   @JoinColumn(name="specialty_id", referencedColumnName="specialty_id")
	 * })
	 */
	private $specialty;

	/**
	 * @ManyToOne(targetEntity="Organization")
	 * @JoinColumns({
	 *   @JoinColumn(name="organization_id", referencedColumnName="organization_id")
	 * })
	 */
	private $organization;

	/************************* Getters/Setters *************************/

	/**
	 * @return Specialty
	 */
	public function getSpecialty()
	{
		return $this->specialty;
	}

	/**
	 * @return Organization
	 */
	public function getOrganization()
	{
		return $this->organization;
	}

	public function getStatus()
	{
		return $this->status;
	}

	public function getStudyMode()
	{
		return $this->studyMode;
	}

	public function getBaseEducation()
	{
		return $this->baseEducation;
	}

	public function getSpecialtyId()
	{
		return $this->specialtyId;
	}

	public function getOrganizationId()
	{
		return $this->organizationId;
	}

	public function getId()
	{
		return $this->organizationSpecialtyId;
	}
}
