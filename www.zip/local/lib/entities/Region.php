<?php

use Doctrine\ORM\Mapping\Entity;
use Doctrine\ORM\Mapping\Column;
use Doctrine\ORM\Mapping\GeneratedValue;
use Doctrine\ORM\Mapping\Id;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @Entity
 * @Table(name="spo_region")
 */
class Region
{
	/**
	 * @Column(name="region_id", type="integer", nullable=false)
	 * @Id
	 * @GeneratedValue
	 */
	private $regionId;

	/**
	 * @var string
	 *
	 * @Column(name="region_name", type="string", length=255, nullable=false)
	 */
	private $regionName;


}
