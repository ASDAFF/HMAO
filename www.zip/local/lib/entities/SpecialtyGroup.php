<?php

use Doctrine\ORM\Mapping\Entity;
use Doctrine\ORM\Mapping\Column;
use Doctrine\ORM\Mapping\GeneratedValue;
use Doctrine\ORM\Mapping\Id;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @Entity
 * @Table(name="spo_specialty_group")
 *
 * Class SpecialtyGroup - группа специальности подготовки
 *
 */
class SpecialtyGroup
{
	/**
	 * @var integer
	 *
	 * @Column(name="specialty_group_id", type="integer", nullable=false)
	 * @Id
	 * @GeneratedValue
	 */
	private $specialtyGroupId;

	/**
	 * @var string
	 *
	 * @ORM\Column(name="specialty_group_title", type="string", length=255, nullable=false)
	 */
	private $specialtyGroupTitle;


}