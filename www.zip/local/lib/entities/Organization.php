<?php

use Doctrine\ORM\Mapping\Entity;
use Doctrine\ORM\Mapping\Column;
use Doctrine\ORM\Mapping\GeneratedValue;
use Doctrine\ORM\Mapping\Id;
use Doctrine\ORM\Mapping\Index;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Organization
 *
 * @Table(name="spo_organization", indexes={@Index(name="city_id", columns={"city_id"})})
 * @Entity
 */
class Organization
{
	/**
	 * @var integer
	 *
	 * @Column(name="organization_id", type="integer", nullable=false)
	 * @Id
	 * @GeneratedValue
	 */
	private $organizationId;

	/**
	 * @var string
	 *
	 * @Column(name="organization_name", type="string", length=255, nullable=false)
	 */
	private $organizationName;

	/**
	 * @var string
	 *
	 * @Column(name="organization_full_name", type="string", length=1000, nullable=false)
	 */
	private $organizationFullName;

	/**
	 * @var integer
	 *
	 * @Column(name="organization_foundation_year", type="integer", nullable=true)
	 */
	private $organizationFoundationYear;

	/**
	 * @var string
	 *
	 * @Column(name="organization_address", type="string", length=1000, nullable=false)
	 */
	private $organizationAddress;

	/**
	 * @var string
	 *
	 * @Column(name="organization_email", type="string", length=255, nullable=true)
	 */
	private $organizationEmail;

	/**
	 * @var string
	 *
	 * @Column(name="organization_phone", type="string", length=255, nullable=false)
	 */
	private $organizationPhone;

	/**
	 * @var string
	 *
	 * @Column(name="organization_site", type="string", length=255, nullable=true)
	 */
	private $organizationSite;

	/**
	 * @ManyToOne(targetEntity="City")
	 * @JoinColumns({
	 *   @JoinColumn(name="city_id", referencedColumnName="city_id")
	 * })
	 */
	private $city;


}
