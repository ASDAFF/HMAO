<?php

use Doctrine\ORM\Mapping\Entity;
use Doctrine\ORM\Mapping\Column;
use Doctrine\ORM\Mapping\GeneratedValue;
use Doctrine\ORM\Mapping\Id;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @Entity
 * @Table(name="spo_specialty")
 *
 * Class Specialty - специальности подготовки
 *
 */
class Specialty
{
    /**
     * @var integer
     *
     * @Column(name="specialty_id", type="integer", nullable=false)
     * @Id
     * @GeneratedValue(strategy="IDENTITY")
     */
    private $specialtyId;

    /**
     * @var integer
     * @Column(name="specialty_group_id", type="integer", nullable=false)
     */
    private $specialtyGroupId;

    /**
     * @var string
     * @Column(name="specialty_title", type="string", length=255, nullable=false)
     */
    private $specialtyTitle;

    /**
     * @var string
     * @Column(name="specialty_code", type="string", length=255, nullable=false, unique=true)
     */
    private $specialtyCode;


	/************************* Relations *************************/

	/**
	 * @OneToOne(targetEntity="SpecialtyGroup")
	 * @JoinColumn(name="specialty_group_id", referencedColumnName="specialty_group_id")
	 */
	private $specialtyGroup;

	/************************* Getters/Setters *************************/

	/**
	 * @return SpecialtyGroup
	 */
	public function getSpecialtyGroup()
	{
		return $this->$specialtyGroup;
	}

	public function getId()
	{
		return $this->$specialtyId;
	}

	public function getSpecialtyGroupId()
	{
		return $this->specialtyGroupId;
	}

	public function getCode()
	{
		return $this->specialtyCode;
	}

	public function getTitle()
	{
		return $this->specialtyTitle;
	}
}
