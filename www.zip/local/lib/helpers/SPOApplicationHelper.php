<?php

class SPOApplicationHelper
{
	public static function listUserApplications(array $applications)
	{
		$result = array();

		/** @var Application $application */
		foreach ($applications as $application) {

			$result[] = array(
				'id' => $application->getId(),
				'creationDate' => $application->getCreationDate(),
				'specialtyTitle' => $application->getOrganizationSpecialty()->getSpecialty()->getTitle(),
				'specialtyCode' => $application->getOrganizationSpecialty()->getSpecialty()->getCode(),
				'studyMode' => SPOStudyMode::getValue($application->getOrganizationSpecialty()->getStudyMode()),
				'baseEducation' => SPOBaseEducation::getValue($application->getOrganizationSpecialty()->getBaseEducation()),
				'status' => SPOApplicationStatus::getValue($application->getStatus()),
			);
		}

		return $result;
	}

	public static function getUserApplication($application)
	{
		/** @var Application $application */
		$result = array(
			'id' => $application->getId(),
			'creationDate' => $application->getCreationDate(),
			'specialtyTitle' => $application->getOrganizationSpecialty()->getSpecialty()->getTitle(),
			'specialtyCode' => $application->getOrganizationSpecialty()->getSpecialty()->getCode(),
			'studyMode' => SPOStudyMode::getValue($application->getOrganizationSpecialty()->getStudyMode()),
			'baseEducation' => SPOBaseEducation::getValue($application->getOrganizationSpecialty()->getBaseEducation()),
			'status' => SPOApplicationStatus::getValue($application->getStatus()),
		);

		return $result;
	}

}