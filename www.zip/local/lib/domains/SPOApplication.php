<?php

use Symfony\Component\Validator\ConstraintViolation;
use \Bitrix\Main;

class SPOApplication {

	public static function getUserApplications($userId)
	{
		$applications = D::$em->getRepository('Application')->getUserApplications($userId);
		return $applications;
	}

	/**
	 * Возвращает заявку пользователя с указанным идентификатором и статусом отличным от "Удалена",
	 * @param integer $userId идентификато рпользователя
	 * @param integer $applicationId идентификатор заявки
	 * @return Application
	 * @throws Bitrix\Main\SystemException
	 */
	public static function getUserApplication($userId, $applicationId)
	{
		$application = D::$em->getRepository('Application')->getActiveUserApplication($userId, $applicationId);
		if ($application === null)
			throw new Main\SystemException('Not Found Exception');

		return $application;
	}

	public static function deleteUserApplication($userId, $applicationId)
	{
		$application = self::getUserApplication($userId, $applicationId);

		$application->setApplicationStatus(SPOApplicationStatus::DELETED);
		//D::$em->persist($application);
		//D::$em->flush($application);

		return true;
	}

	public static function getAllApplications()
	{


//		$application = new Application();
//		$application->setMessage('test');
//
//		$validationErrors = D::$v->validate($application);
//
//		if($validationErrors->count()){
//			/** @var ConstraintViolation $error */
//			foreach ($validationErrors as $error) {
//				echo $error->getMessage().'<br>';
//			}
//		}

//		$application->setTitle('Title');

//		D::$em->persist($application);
//		D::$em->flush();

		$result = array();
		$applications = D::$em->getRepository('Application')->findAll();
		/** @var Application $application */
		foreach ($applications as $application) {
			$result[] = array(
				'id' => $application->getId(),
				'creationDate' => $application->getCreationDate(),
				'specialtyTitle' => $application->getSpecialty()->getTitle(),
				'userFullName' => $application->getBitrixUser()->getFullName(),
			);
		}

		return $result;
	}
}