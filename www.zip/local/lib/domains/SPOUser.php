<?php

class SPOUser
{
	const ABITURIENTS_IBLOCK_ID = 2;
	const ORGANIZATIONS_IBLOCK_ID = 3;

	// todo возможно, стоит ориентироваться на символьные коды групп пользователей и получать id групп динамически,
	// todo нужен отдельный класс. Зависит от дальнейшей судьбы проекта, метода его установки, и т.д.

	// todo хэндлеры вынести в какой-нибудь класс

	const ABITURIENTS_GROUP_ID = 5;
	const UNCONFIRMED_ORGANIZER_GROUP_ID = 6;
	const ORGANIZER_GROUP_ID = 7;

	// Соответствие символьных кодов, пришедших с формы, идентификаторам групп пользователей
	public static $userGroups = array(
		'abiturient' => self::ABITURIENTS_GROUP_ID,
		'organization' => self::UNCONFIRMED_ORGANIZER_GROUP_ID,
	);

	function beforeUserRegister(&$arFields)
	{
		// По параметрам запроса определяет, регистрация какого типа пользователя происходит
		// и устанавливает соответствующую группу пользователей. Если необходимое значение с формы регистрации не пришло
		//  - прерываем выполнение скрипта и выдаём ошибку. Пользователь зарегистрирован не будет.

		global $APPLICATION;

		$requestUserRole = $_REQUEST['userRole'];

		if  (empty($requestUserRole)) {
			$APPLICATION->ThrowException('Некорректные данные указаны при регистрации: не выбран тип аккаунта');
			return false;
		}

		if (!isset(self::$userGroups[$requestUserRole])) {
			$APPLICATION->ThrowException('Некорректные данные указаны при регистрации: недоступный тип аккаунта');
			return false;
		}

		$arFields['GROUP_ID'] = array(self::$userGroups[$requestUserRole]);

		return true;
	}

	function afterUserAdd(&$arFields)
	{
		// Должен быть определён код пользователя, если регистрация прошла успешно. Иначе завершаем обработку.
		if (empty($arFields['ID']))
			return true;

		if (!CModule::IncludeModule('iblock')) {
			AddMessage2Log('iblock module not found');
			die('iblock module not found');
		}

		$userId = $arFields['ID'];
		$userLogin = $arFields['LOGIN'];
		$userGroups = $arFields['GROUP_ID'];

		if (self::checkUserGroups(self::ABITURIENTS_GROUP_ID, $userGroups)) {
			return self::afterAbiturientCreation($userId, $userLogin);
		} elseif (self::checkUserGroups(self::UNCONFIRMED_ORGANIZER_GROUP_ID, $userGroups)) {
			$organizationIBlockElementId = (isset($arFields['UF_EDUORG'])) ? $arFields['UF_EDUORG'] : null;
			return self::afterOrganizationCreation($userId, $userLogin, $organizationIBlockElementId);
		}

		return true;
	}

	function afterUserRegister(&$arFields)
	{
		// Должен быть определён код пользователя, если регистрация прошла успешно. Иначе завершаем обработку.
		if (empty($arFields['USER_ID']))
			return true;

		if (!CModule::IncludeModule('iblock')) {
			AddMessage2Log('iblock module not found');
			die('iblock module not found');
		}

		$userId = $arFields['USER_ID'];
		$userLogin = $arFields['LOGIN'];
		$userGroups = $arFields['GROUP_ID'];

		if (in_array(self::ABITURIENTS_GROUP_ID, $userGroups)) {
			return self::afterAbiturientCreation($userId, $userLogin);
		} elseif (in_array(self::UNCONFIRMED_ORGANIZER_GROUP_ID, $userGroups)) {
			$organizationIBlockElementId = (isset($arFields['UF_EDUORG'])) ? $arFields['UF_EDUORG'] : null;
			return self::afterOrganizationCreation($userId, $userLogin, $organizationIBlockElementId);
		}

		return true;
	}

	private static function checkUserGroups($groupId, $userGroups)
	{
		foreach ($userGroups as $group) {
			if ($group['GROUP_ID'] == $groupId)
				return true;
		}

		return false;
	}

	/**
	 * Проверяет, есть ли среди идентификаторов в переданом массиве идентификатор, соответствующий группе "Абитуриенты"
	 *
	 * @param array $groupsIds
	 * @return bool
	 */
	public static function checkIsAbiturient(array $groupsIds)
	{
		return self::checkUserGroups(self::ABITURIENTS_GROUP_ID, $groupsIds);
	}

	private function afterAbiturientCreation($userId, $userLogin)
	{
		$abiturient = new CIBlockElement;

		// Инфоблок абитуриента должен быть привязан к конкретному пользователю
		$propertyValues = array();
		$propertyValues['USER'] = $userId;

		$abiturientAttributes = Array(
			'IBLOCK_SECTION_ID' => false,
			'IBLOCK_ID' => self::ABITURIENTS_IBLOCK_ID,
			'PROPERTY_VALUES' => $propertyValues,
			'NAME' =>  $userLogin,
			'ACTIVE' => 'Y',
		);

		if(!$abiturientIBlockId = $abiturient->Add($abiturientAttributes)) {
			AddMessage2Log('Ошибка при создании инфоблока абитуриента. ' . $abiturient->LAST_ERROR);
			return false;
		}

		return true;
	}

	private function afterOrganizationCreation($userId, $userLogin, $organizationIBlockElementId)
	{
		// Проверка переданой с формы регистрации организации. Если инфоблок для этой организации ещё не существует,
		// его необходимо создать
		$organizationExist = CIBlockElement::GetByID($organizationIBlockElementId)->GetNext();

		if (!$organizationExist)
		{
			$organization = new CIBlockElement;

			$organizationAttributes = Array(
				'IBLOCK_ID' => self::ORGANIZATIONS_IBLOCK_ID,
				'NAME' =>  $userLogin,
				'ACTIVE' => 'Y',
			);

			if(!$organizationIBlockElementId = $organization->Add($organizationAttributes)) {
				AddMessage2Log('Ошибка при создании инфоблока организации. ' . $organization->LAST_ERROR);
				return false;
			}
		}

		// Каждый пользователь, относящийся к персоналу организации, должен быть привязан к инфоблоку организации
		$user = new \CUser;
		$user->Update($userId, array('UF_EDUORG' => $organizationIBlockElementId));

		if (!empty($user->LAST_ERROR)) {
			AddMessage2Log('Ошибка при привязке пользователя к инфоблоку организации. ' . $user->LAST_ERROR);
			return false;
		}

		return true;
	}
}
?>