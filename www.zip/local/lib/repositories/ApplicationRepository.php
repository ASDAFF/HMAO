<?php

use Doctrine\ORM\EntityRepository;

class ApplicationRepository extends EntityRepository
{
	public function getUserApplications($userId)
	{
		// Alternative
		// $dql = 'SELECT a, os, s FROM Application a
		//		JOIN a.organizationSpecialty os JOIN os.specialty s
		//		WHERE a.userId = ?1';

		//$query = $this->getEntityManager()
		//	->createQuery($dql)
		//	->setParameter(1, $userId);

		$qb = $this->createQueryBuilder('a')
			->select('a, os, s')
			->innerJoin('a.organizationSpecialty', 'os')
			->innerJoin('os.specialty', 's')
			->where('a.userId = :userId')
			->setParameter('userId', $userId);

		return $qb->getQuery()->getResult();
	}

	public function getActiveUserApplication($userId, $applicationId)
	{
		// TODO Можно ли использовать свой QueryBuilder, чтобы реализовать что-то вроде yii named scopes для
		// TODO формирования запроса с условием по статусу через ->onlyActive()
		$qb = $this->createQueryBuilder('a')
				->select('a')
				->where('a.userId = :userId AND a.applicationId = :applicationId AND a.applicationStatus != :status')
				->setParameters(array(
					'userId' => $userId,
					'applicationId' => $applicationId,
					'status' => SPOApplicationStatus::DELETED,
				));

		return $qb->getQuery()->getSingleResult();
	}
}