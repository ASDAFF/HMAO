<?php

$_SERVER['DOCUMENT_ROOT'] = realpath(dirname(__FILE__) . '/../..');
$DOCUMENT_ROOT = $_SERVER['DOCUMENT_ROOT'];

define('NO_KEEP_STATISTIC', true);
define('NOT_CHECK_PERMISSIONS', true);
define('LANG', 'ru');
set_time_limit(0);

require($DOCUMENT_ROOT . '/bitrix/modules/main/include/prolog_before.php');

// Путь к файлу логов. Не забыть закрыть папку с логами от внешнего доступа, например, через .htaccess
define('LOG_FILENAME', $DOCUMENT_ROOT. '/local/logs/KonkursAPILog.txt');
define('NEWS_IBLOCK_ID', 3); // идентификатор  инфоблока для добавления новостей (id=13 для umnik.fasie.ru)
define('NEWS_LIMIT', 3); // количество новостей, запрашиваемое за раз (0 - без ограничения)
define('IBLOCK_TYPE', 'news'); // идентификатор типа инфоблока
define('DEFAULT_SECTION_ID', 4); // идентификатор секции, в которую попадут новости с не привязанным ни к одной секции site_global_id

if (!CModule::IncludeModule('iblock')) {
	AddMessage2Log('Не подключен модуль "Инфоблоки"');
	die('iblock module not found');
}

$lastNewsId = getLastNewsExternalId();

// Получение новостей с konkurs-online
$konkursAPI = new KonkursAPI('/news/listNews');
$newsList = $konkursAPI->sendRequest(array('limit' => NEWS_LIMIT, 'afterId' => $lastNewsId));

if ($konkursAPI->error) {
	AddMessage2Log($konkursAPI->error);
	die($konkursAPI->error);
}

if (empty($newsList))
	die();

$siteGlobalIdsBySectionId = getSiteGlobalIdsWitSectionId();
createNewsIBlocks($newsList, $siteGlobalIdsBySectionId);

function createNewsIBlocks($newsArray, $siteGlobalIdsBySectionId)
{
	// Чтобы контролировать уникальность добавляемых konkurs_id без лишних запросов в базу, необходимо установить
	// настройку "Поля -> Символьный код -> Если код задан, то проверять на уникальность"
	// Для добавляемых элементов инфоблока генерируется символьный код вида konkurs_id<site_news_id>
	foreach ($newsArray as $news)
	{
		if (isset($siteGlobalIdsBySectionId[$news['site_global_id']]))
			$sectionId = $siteGlobalIdsBySectionId[$news['site_global_id']];
		else
			$sectionId = DEFAULT_SECTION_ID;

		$ib = new CIBlockElement();
		$arFields = Array(
			'ACTIVE' => 'N',
			'NAME' => $news['site_news_title'],
			'PROPERTY_VALUES' => array(
				'konkurs_id' => $news['site_news_id'],
			),
			'DETAIL_TEXT' => $news['site_news_text'],
			'DETAIL_TEXT_TYPE' => 'html',
			'PREVIEW_TEXT' => $news['site_news_announce'],
			'PREVIEW_TEXT_TYPE' => 'html',
			'IBLOCK_SECTION_ID' => $sectionId,
			'IBLOCK_ID' => NEWS_IBLOCK_ID,
			'CODE' => 'konkurs_id' . $news['site_news_id'],
		);

		if($elementId = $ib->Add($arFields)) {
			echo 'New ID: '. $elementId;
			AddMessage2Log('Добавлена новость c ID ' . $news['site_news_id'] . ' ID элемента инфоблока ' . $elementId);
		} else {
			echo 'Error: ' . $ib->LAST_ERROR;
			AddMessage2Log('Произошла ошибка при добавлении новости c ID:  ' .  $news['site_news_id'] . '; Ошибка: ' . $ib->LAST_ERROR);
		}
	}
}

function getSiteGlobalIdsWitSectionId()
{
	// Выбираем все разделы инфоблока с IBLOCK_ID = NEWS_IBLOCK_ID, при условии, что поле раздела UF_SITEGLOBAL не пустое
	$sectionList = CIBlockSection::GetList(
		array('SORT' => 'ASC'),
		array('IBLOCK_ID' => NEWS_IBLOCK_ID, '!UF_SITE_GLOBAL_ID' => false),
		false,
		array('IBLOCK_ID', 'ID', 'UF_SITE_GLOBAL_ID')
	);

	$sectionWithSiteGlobalIds = array();
	while($section = $sectionList->GetNextElement())
	{
		$sectionWithSiteGlobalIds[$section->fields['UF_SITE_GLOBAL_ID']] = $section->fields['ID'];
	}

	return $sectionWithSiteGlobalIds;
}

function getLastNewsExternalId()
{
	// Необходимо у инфоблока с типом "news" создать свойство с кодом "konkurs_id"
	// В выборку попадают только те инфоблоки, у которых значение свойства konkurs_id не пустые
	$arFilter = array('IBLOCK_TYPE' => IBLOCK_TYPE, '!PROPERTY_KONKURS_ID' => false);

	// Сортируем по убыванию и выбираем один элемент (nTopCount) - получим только элемент с наибольшим konkurs_id
	$newsList = CIBlockElement::GetList(
		array('PROPERTY_KONKURS_ID' => 'DESC'),
		$arFilter,
		false,
		array ("nTopCount" => 1),
		array('IBLOCK_ID', 'ID', 'PROPERTY_KONKURS_ID_VALUE')
	);

	$lastNews = $newsList->GetNextElement();
	return empty($lastNews) ? 0 : intval($lastNews->fields['PROPERTY_KONKURS_ID_VALUE']);
}

require($DOCUMENT_ROOT . '/bitrix/modules/main/include/epilog_after.php');
?>