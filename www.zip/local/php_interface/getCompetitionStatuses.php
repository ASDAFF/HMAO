<?php

// Статусы konkurs-online
const KONKURS_STATUS_UNKNOWN = 1; // Статус неизвестен
const KONKURS_PREPARATION = 2; // Подготовка
const KONKURS_REQUEST_RECEIVING = 3; // Сбор заявок
const KONKURS_SUMMING_UP = 4; // Подведение итогов
const KONKURS_WINNERS_ANNOUNCEMENT = 5; // Объявлены победители

// Внутренние статусы
const ACCREDITATION_DECLINED = 0;
const STATUS_UNKNOWN = -1; // Статус неизвестен
const PREPARATION = 4; // Подготовка (? не такого статуса в битриксе сейчас)
const REQUEST_RECEIVING = 1; // Сбор заявок
const SUMMING_UP = 2; // Подведение итогов (статус "финальное мероприятие")
const WINNERS_ANNOUNCEMENT = 3; // Объявлены победители

$_SERVER['DOCUMENT_ROOT'] = realpath(dirname(__FILE__) . '/../..');
$DOCUMENT_ROOT = $_SERVER['DOCUMENT_ROOT'];

define('NO_KEEP_STATISTIC', true);
define('NOT_CHECK_PERMISSIONS', true);
define('LANG', 'ru');
set_time_limit(0);

require($DOCUMENT_ROOT . '/bitrix/modules/main/include/prolog_before.php');

// Путь к файлу логов. Не забыть закрыть папку с логами от внешнего доступа, например, через .htaccess
define('LOG_FILENAME', $DOCUMENT_ROOT. '/local/logs/KonkursAPILog.txt');
define('IBLOCK_ID', 4); // Идентификатор  инфоблока региональных представительств (11 для umnik.fasie.ru)

if (!CModule::IncludeModule('iblock')) {
	AddMessage2Log('Не подключен модуль "Инфоблоки"');
	die('iblock module not found');
}

$konkursAPI = new KonkursAPI('/competition/listAccreditationCompetitionStatuses');
$siteGlobalIdStatuses = $konkursAPI->sendRequest(array('limit' => 0));

if ($konkursAPI->error) {
	AddMessage2Log($konkursAPI->error);
	die('API Error' . $konkursAPI->error . PHP_EOL);
}

if (empty($siteGlobalIdStatuses))
	die('Empty API Response');

$siteGlobalIds = array();
$siteGlobalStatuses = array();
foreach ($siteGlobalIdStatuses as $s)
{
	$siteGlobalIds[] = $s['site_global_id'];
	$siteGlobalStatuses[$s['site_global_id']] = convertKonkursStatus(
		$s['accreditation_status'], $s['examination_status']
	);

	//test
	echo 'sgi' . $s['site_global_id'] . ' accrStatus ' . $s['accreditation_status'] . ' examinationStatus ' . $s['examination_status'];
	echo ' convertedStatus ' . convertKonkursStatus($s['accreditation_status'], $s['examination_status']) . PHP_EOL;
}
die();
$arFilter = array('IBLOCK_ID' => IBLOCK_ID, 'EXTERNAL_ID' => $siteGlobalIds);

$representations = CIBlockElement::GetList(
	array(),
	$arFilter,
	false,
	false,
	array('IBLOCK_ID', 'ID', 'EXTERNAL_ID', 'PROPERTY_STATUS')
);

while ($representation = $representations->GetNextElement())
{
	$externalId = $representation->fields['EXTERNAL_ID'];

	if ($representation->fields['PROPERTY_STATUS_VALUE'] != intval($siteGlobalStatuses[$externalId]))
	{
		CIBlockElement::SetPropertyValuesEx(
			$representation->fields['ID'],
			IBLOCK_ID,
			array('STATUS' => $siteGlobalStatuses[$externalId])
		);
	}
}

function convertKonkursStatus($accreditationStatus, $examinationStatus)
{
	$statusCorrespondence = array(
		KONKURS_PREPARATION => PREPARATION,
		KONKURS_REQUEST_RECEIVING => REQUEST_RECEIVING,
		KONKURS_SUMMING_UP => SUMMING_UP,
		KONKURS_WINNERS_ANNOUNCEMENT => WINNERS_ANNOUNCEMENT,
	);

	if ($accreditationStatus == 5)
		return ACCREDITATION_DECLINED;

	if ($accreditationStatus != 3)
		return STATUS_UNKNOWN;

	return isset($statusCorrespondence[$examinationStatus]) ? $statusCorrespondence[$examinationStatus] : STATUS_UNKNOWN;
}

require($DOCUMENT_ROOT . '/bitrix/modules/main/include/epilog_after.php');
?>