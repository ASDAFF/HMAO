<?php

$_SERVER['DOCUMENT_ROOT'] = realpath(dirname(__FILE__) . '/../..');
$DOCUMENT_ROOT = $_SERVER['DOCUMENT_ROOT'];

define('NO_KEEP_STATISTIC', true);
define('NOT_CHECK_PERMISSIONS', true);
define('LANG', 'ru');
set_time_limit(0);

// В данном скипте подключаем prolog_admin_before.php. Если использовать prolog_before.php, то константа FORMAT_DATETIME
// будет определена и равна NULL. Определённую константу переопределить не можем, а она используется в ядре битрикса при
// проверке формата даты, присваеваемой свойству создаваемого через Add() элемента инфоблока. Такие дела.
// Важно: после подключения prolog_admin_before константа SITE_ID равна "ru", так как при инициализации в
// административной части константа указывает на используемый язык административной части
// (см. http://dev.1c-bitrix.ru/community/forums/forum6/topic16388/)
// Поэтому, вместо использования SITE_ID в данном скрипте напрямую подставляем нужный идентификатор сайта ("s1")/
// Например: ConvertTimeStamp($konkursStageData['examination_stage_start_date'], 'FULL', 's1')
require($DOCUMENT_ROOT . '/bitrix/modules/main/include/prolog_admin_before.php');

// Путь к файлу логов. Не забыть закрыть папку с логами от внешнего доступа, например, через .htaccess
define('LOG_FILENAME', $DOCUMENT_ROOT. '/local/logs/KonkursAPILog.txt');
define('REPRESENTATION_IBLOCK_ID', 4); // Идентификатор инфоблока региональных представительств (11 для umnik.fasie.ru)
define('SEMIFINAL_IBLOCK_ID', 5); // Идентификатор инфоблока полуфинального мероприятия (12 для umnik.fasie.ru)

if (!CModule::IncludeModule('iblock')) {
	AddMessage2Log('Не подключен модуль "Инфоблоки"');
	die('iblock module not found');
}

$konkursAPI = new KonkursAPI('/competition/listAccreditationRequestWithExaminationStages');
$siteGlobalStages = $konkursAPI->sendRequest(array('limit' => 0));

if ($konkursAPI->error) {
	AddMessage2Log($konkursAPI->error);
	die($konkursAPI->error);
}

if (empty($siteGlobalStages))
	die();

foreach ($siteGlobalStages as $siteGlobal) {

	$representation = findRepresentationElement($siteGlobal['site_global_id']);

	if (!$representation) {
		AddMessage2Log(
			'Не найден элемент инфоблока "Региональные представительсва" с EXTERNAL_ID = ' . $siteGlobal['site_global_id']
		);
		continue;
	}

	$actualExaminationStagesId = array();
	foreach ($siteGlobal['examination_stages'] as $stage) {
		if ($stage['is_final_stage']) {
			UpdateFinalStage($representation->fields['ID'], $stage);
		} else {
			$actualExaminationStagesId[] = $stage['examination_stage_id'];
			$semifinal = findSemifinal($stage['examination_stage_id']);

			if (!$semifinal)
				createNewSemifinal($representation->fields['ID'], $stage);
			else
				updateSemifinal($semifinal->fields['ID'], $stage);
		}
	}

	deleteNonActualSemifinals($representation->fields['ID'], $actualExaminationStagesId);

}

function deleteNonActualSemifinals($representationElementId, array $actualExaminationStagesId)
{
	// Все полуфиналы, которые привязаны к данному представительству, но не пришли от konkurs-online
	// (не оказались в $actualExaminationStagesId) нужно удалить - например, полуфиналы с предыдущего периода конкурса.
	$semifinalsToDelete = CIBlockElement::GetList(
		array(),
		array(
			'IBLOCK_ID' => SEMIFINAL_IBLOCK_ID,
			'!EXTERNAL_ID' => $actualExaminationStagesId, // Отбор по NOT IN (..., ...)
			'PROPERTY_REGION_REPRESENTATION_VALUE' => $representationElementId),
		false,
		array(),
		array('IBLOCK_ID', 'ID', 'EXTERNAL_ID')
	);

	while ($semifinalToDelete = $semifinalsToDelete->GetNextElement()) {
		if(!CIBlockElement::Delete($semifinalToDelete->fields['ID'])) {
			AddMessage2Log('Не удалось удалить полуфинал ' . $semifinalToDelete->fields['ID'] . PHP_EOL);
		} else {
			AddMessage2Log('Удалён полуфинал ' . $semifinalToDelete->fields['ID'] . PHP_EOL);
		}
	}
}

function findRepresentationElement($siteGlobalId)
{
	$representation = CIBlockElement::GetList(
		array(),
		array('IBLOCK_ID' => REPRESENTATION_IBLOCK_ID, 'EXTERNAL_ID' => $siteGlobalId),
		false,
		array(),
		array('IBLOCK_ID', 'ID')
	);

	// В БД должен быть один единственный инфоблок с EXTERNAL_ID = site_global_id.
	// Проверка на наличие нескольких не проводится, обрабатывается только один
	return $representation->GetNextElement();
}

function updateFinalStage($elementId, $konkursStageData)
{
	CIBlockElement::SetPropertyValuesEx(
		$elementId,
		REPRESENTATION_IBLOCK_ID,
		array(
			'FINAL_EVENT' => ConvertTimeStamp($konkursStageData['examination_stage_start_date'], 'FULL', 's1'),
			'FINAL_EVENT_END_DATE' => ConvertTimeStamp($konkursStageData['examination_stage_end_date'], 'FULL', 's1'),
		)
	);
}

function findSemifinal($externalId)
{
	$semifinal = CIBlockElement::GetList(
		array(),
		array('IBLOCK_ID' => SEMIFINAL_IBLOCK_ID, 'EXTERNAL_ID' => $externalId),
		false,
		array(),
		array('IBLOCK_ID', 'ID')
	);

	// В БД должен быть один единственный инфоблок с EXTERNAL_ID = examination_stage_id.
	// Проверка на наличие нескольких не проводится, обрабатывается только один
	return $semifinal->GetNextElement();
}

function createNewSemifinal($representationElementId, $konkursStageData)
{
	$startDate = ConvertTimeStamp($konkursStageData['examination_stage_start_date'], 'FULL', 's1');
	$endDate = ConvertTimeStamp($konkursStageData['examination_stage_end_date'], 'FULL', 's1');

	$ib = new CIBlockElement();
	$arFields = Array(
		'ACTIVE' => 'N',
		'NAME' => $konkursStageData['examination_stage_title'],
		'PROPERTY_VALUES' => array(
			'EVENT_DATE' => $startDate,
			'EVENT_END_DATE' => $endDate,
			'REGION_REPRESENTATION' => $representationElementId,
		),
		'IBLOCK_SECTION_ID' => false,
		'IBLOCK_ID' => SEMIFINAL_IBLOCK_ID,
		'EXTERNAL_ID' => $konkursStageData['examination_stage_id'],
	);

	if($elementId = $ib->Add($arFields)) {
		echo 'New semifinal ID: '. $elementId;
		AddMessage2Log(
			'Добавлен полуфинал для examination_stage_id ' .
			$konkursStageData['examination_stage_id'] .
			' ID элемента инфоблока ' . $elementId
		);
	} else {
		echo 'Error: ' . $ib->LAST_ERROR;
		AddMessage2Log(
			'Произошла ошибка при создании полуфинала c examination_stage_id:  ' .
			$konkursStageData['examination_stage_id'] .
			'; Ошибка: ' . $ib->LAST_ERROR
		);
	}
}

function updateSemifinal($elementId, $konkursStageData)
{
	CIBlockElement::SetPropertyValuesEx(
		$elementId,
		SEMIFINAL_IBLOCK_ID,
		array(
			'EVENT_DATE' => ConvertTimeStamp($konkursStageData['examination_stage_start_date'], 'FULL', 's1'),
			'EVENT_END_DATE' => ConvertTimeStamp($konkursStageData['examination_stage_end_date'], 'FULL', 's1'),
		)
	);

	// Отдельно обновляем наименование полуфинала. Метод SetPropertyValuesEx, ипользованнй выше, работает только с
	// "пользовательскими" свойствами иноблока. Значения "системных" свойств (NAME, CODE, и пр.) можно изменить только
	// через Update(); С другой стороны, Update() может обновлять и "пользовательские" свойства элемента, однако для
	// обновления одного такого свойства (например, EVENT_END_DATE), необходимо сформировать полный список всех
	// "пользовательских" свойств с их значениями. Если же не передать методу Update() этот полный список, он обновит
	// значение только указанного свойства, а значения остальных (НЕ указанных) удалит.
	// См. документацию http://dev.1c-bitrix.ru/api_help/iblock/classes/ciblockelement/update.php
	$el = new CIBlockElement;
	$el->Update($elementId, array('NAME' => $konkursStageData['examination_stage_title']));

}

require($DOCUMENT_ROOT . '/bitrix/modules/main/include/epilog_after.php');
?>