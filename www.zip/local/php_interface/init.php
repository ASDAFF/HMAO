<?php

// TODO Сомнительное удовольствие использовать встроеный логгер битрикса. Возможно, стоит подключить сторонний класс.
// TODO Возможно, стоит записывать ошибки как события в журнал событий:
// TODO https://dev.1c-bitrix.ru/community/webdev/user/11948/blog/2647/
define('LOG_FILENAME', $_SERVER['DOCUMENT_ROOT'] . '/local/logs/SPO.txt');

CModule::AddAutoloadClasses('', array(
	'CVarDumper' => '/local/extra/CVarDumper.php',
));

// Обработчик события регистрации нового пользователя. Выполняется ДО регистрации пользователя. При неудачном завершении
// пользователь зарегистрирован не будет. Не выполняется при регистрации пользователя из административной части
AddEventHandler('main', 'OnBeforeUserRegister', Array('SPOUser', 'beforeUserRegister'));

// Выполняется после факта регистрации пользователя в системе. Основываясь на группе пользователя, создаёт необходимые
// инфоблоки для пользователя. При неудачном завершении пользователь всё равно будет создан в системе.
AddEventHandler('main', 'OnAfterUserRegister', Array('SPOUser', 'afterUserRegister'));
// Аналогично, но выполняется только при создании пользователя из административной части. Для метода afterUserAdd
// набор входных параметров будет отличен от входных параметров метода afterUserRegister, поэтому и используются два
// разных метода (методы почти аналогичн, возможно, стоит объединить их или найти подходящий обработчик событий для
// обоих случаев)
AddEventHandler('main', 'OnAfterUserAdd', Array('SPOUser', 'afterUserAdd'));


function SPODomainsAutoloader($class) {
	if (file_exists($_SERVER['DOCUMENT_ROOT'] . '/local/lib/domains/' . $class . '.php')) {
		require_once $_SERVER['DOCUMENT_ROOT'] . '/local/lib/domains/' . $class . '.php';
	}
}

function SPOHelpersAutoloader($class) {
	if (file_exists($_SERVER['DOCUMENT_ROOT'] . '/local/lib/helpers/' . $class . '.php')) {
		require_once $_SERVER['DOCUMENT_ROOT'] . '/local/lib/helpers/' . $class . '.php';
	}
}

function SPODictionariesAutoloader($class) {
	if (file_exists($_SERVER['DOCUMENT_ROOT'] . '/local/lib/dictionaries/' . $class . '.php')) {
		require_once $_SERVER['DOCUMENT_ROOT'] . '/local/lib/dictionaries/' . $class . '.php';
	}
}

spl_autoload_register('SPODomainsAutoloader');
spl_autoload_register('SPOHelpersAutoloader');
spl_autoload_register('SPODictionariesAutoloader');
