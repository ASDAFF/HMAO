<?
if(!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true)
	die();
?>
<!DOCTYPE html>
<html>
	<head>
		<?$APPLICATION->ShowHead();?>
		<title><?$APPLICATION->ShowTitle();?></title>
		<link rel="shortcut icon" type="image/x-icon" href="/favicon.ico" /> 	
	</head>
	<body>
		<div id="panel">
			<?$APPLICATION->ShowPanel();?>
		</div>

		<div style="float: left; padding: 10px "><a href="">Регистрация абитуриента</a></div>
		<div style="float: left; padding: 10px "><a href="">Регистрация организации</a></div>

		<div style="float: right; padding: 0 0 0 500px">
		<?$APPLICATION->IncludeComponent(
	"bitrix:system.auth.form", 
	"header-form", 
	array(
		"REGISTER_URL" => "",
		"FORGOT_PASSWORD_URL" => "",
		"PROFILE_URL" => "",
		"SHOW_ERRORS" => "N"
	),
	false
);?>
		</div>

		<?$APPLICATION->IncludeComponent(
			"bitrix:menu",
			"horizontal_multilevel",
			array(
				"ROOT_MENU_TYPE" => "top",
				"MAX_LEVEL" => "2",
				"CHILD_MENU_TYPE" => "left",
				"USE_EXT" => "Y",
				"DELAY" => "N",
				"ALLOW_MULTI_SELECT" => "N",
				"MENU_CACHE_TYPE" => "N",
				"MENU_CACHE_TIME" => "3600",
				"MENU_CACHE_USE_GROUPS" => "Y",
				"MENU_CACHE_GET_VARS" => array()
			),
			false
);?>
