<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die(); ?>
<?
use \Bitrix\Main\Localization\Loc as Loc;
Loc::loadMessages(__FILE__);
?>

<h3>Заявка № <?= $arResult['application']['id']?></h3>


<table border="1">
	<tr>
		<td>Дата подачи заявления</td>
		<td><?= $arResult['application']['creationDate'] ?></td>
	</tr>
	<tr>
		<td>Специальность</td>
		<td><?= $arResult['application']['specialtyTitle'] ?></td>
	</tr>
	<tr>
		<td>Код специальности</td>
		<td><?= $arResult['application']['specialtyCode'] ?></td>
	</tr>
	<tr>
		<td>Форма обучения</td>
		<td><?= $arResult['application']['studyMode'] ?></td>
	</tr>
	<tr>
		<td>Базовое образование</td>
		<td><?= $arResult['application']['baseEducation'] ?></td>
	</tr>
	<tr>
		<td>Статус заявления</td>
		<td><?= $arResult['application']['status'] ?></td>
	</tr>
</table>



