<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

use \Bitrix\Main;
use \Bitrix\Main\Localization\Loc as Loc;

class ElementDetailComponent extends AbiturientOffice
{
	protected function checkParams()
	{
		if (empty($this->arParams['APPLICATION_ID']))
			throw new Main\ArgumentNullException('APPLICATION_ID');
	}

	protected function getResult()
	{
		global $USER;
		$userId = $USER->GetID();
		$this->arResult['application'] = SPOApplicationHelper::getUserApplication(
			SPOApplication::getUserApplication($userId, $this->arParams['APPLICATION_ID'])
		);
	}

	public function executeComponent()
	{
		try {
			$this->checkModules();
			$this->checkParams();
			$this->getResult();
			$this->includeComponentTemplate();
		} catch (Exception $e) {
			ShowError($e->getMessage());
		}
	}
}
?>