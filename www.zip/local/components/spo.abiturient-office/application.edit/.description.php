<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => 'Заявление на поступление',
	"DESCRIPTION" => 'Компонент для отображения и редактирования заявления абитуриента на поступление ',
	"ICON" => '/images/icon.gif',
	"SORT" => 20,
//	"PATH" => array(
//		"ID" => 'SPO',
//		"NAME" => 'СПО',
//		"SORT" => 10,
//		"CHILD" => array(
//			"ID" => 'somesection',
//			"NAME" => 'Стандартные компоненты',
//			"SORT" => 10
//		)
//	),
);