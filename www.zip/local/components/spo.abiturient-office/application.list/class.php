<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

use \Bitrix\Main;
use \Bitrix\Main\Localization\Loc as Loc;

// TODO разобраться, есть ли смысл наследовать класс "подкомпонента" от главного класса комплексного компонента,
// TODO или оставить его наследником CBitrixComponent
class ApplicationListComponent extends AbiturientOffice
{

	public function onIncludeComponentLang()
	{
		parent::onIncludeComponentLang();

		$this->includeComponentLang(basename(__FILE__));
		Loc::loadMessages(__FILE__);
	}

    public function onPrepareComponentParams($params)
    {
//        $result = array(
//            'IBLOCK_TYPE' => trim($params['IBLOCK_TYPE']),
//            'IBLOCK_ID' => intval($params['IBLOCK_ID']),
//            'SHOW_NAV' => ($params['SHOW_NAV'] == 'Y' ? 'Y' : 'N'),
//            'COUNT' => intval($params['COUNT']),
//            'SORT_FIELD1' => strlen($params['SORT_FIELD1']) ? $params['SORT_FIELD1'] : 'ID',
//            'SORT_DIRECTION1' => $params['SORT_DIRECTION1'] == 'ASC' ? 'ASC' : 'DESC',
//            'SORT_FIELD2' => strlen($params['SORT_FIELD2']) ? $params['SORT_FIELD2'] : 'ID',
//            'SORT_DIRECTION2' => $params['SORT_DIRECTION2'] == 'ASC' ? 'ASC' : 'DESC',
//            'CACHE_TIME' => intval($params['CACHE_TIME']) > 0 ? intval($params['CACHE_TIME']) : 3600
//        );
//        return $result;
		return $params;
    }

	protected function checkParams()
	{
//		if ($this->arParams['IBLOCK_ID'] <= 0)
//			throw new Main\ArgumentNullException('IBLOCK_ID');
	}

	protected function getResult()
	{
		global $USER;
		$this->arResult['userApplications'] = SPOApplicationHelper::listUserApplications(
			SPOApplication::getUserApplications($USER->GetID())
		);
	}

	public function executeComponent()
	{
		try {
			$this->checkModules();
			$this->checkParams();
			$this->getResult();
			$this->includeComponentTemplate();
		} catch (Exception $e) {
			ShowError($e->getMessage());
		}
	}
}
?>