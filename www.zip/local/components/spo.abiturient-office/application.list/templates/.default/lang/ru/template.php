<?
$MESS['STANDARD_ELEMENTS_LIST_TEMPLATE_TITLE'] = 'Список элементов';
?>