<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die(); ?>

<table border="1">
	<?php foreach ($arResult['userApplications'] as $application): ?>
	<tr>
		<td><?= $application['id'] ?></td>
		<td><?= $application['creationDate'] ?></td>
		<td><?= $application['specialtyTitle'] ?></td>

		<td><?= $application['specialtyCode'] ?></td>
		<td><?= $application['studyMode'] ?></td>
		<td><?= $application['baseEducation'] ?></td>
		<td><?= $application['status'] ?></td>
		<td><a href="edit/<?= $application['id']?>/">Изменить</a></td>
	</tr>
	<?php endforeach; ?>
</table>


