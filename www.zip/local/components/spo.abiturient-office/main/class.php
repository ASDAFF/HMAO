<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

use \Bitrix\Main;
use \Bitrix\Main\Localization\Loc;

class AbiturientOffice extends CBitrixComponent
{

	public function onIncludeComponentLang()
	{
		$this->includeComponentLang(basename(__FILE__));
		Loc::loadMessages(__FILE__);
	}

	// Для задания путей "по-умолчанию" для работы в ЧПУ режиме
	protected $arDefaultUrlTemplates404 = array(
		'applicationList' => 'index.php',
		'applicationEdit' => 'edit/#APPLICATION_ID#/',
	);

	// Для задания псевдонимов "по-умолчанию" переменных в режиме ЧПУ. Как правило массив пустой
	protected $arDefaultVariableAliases404 = array();

	protected $arUrlTemplates = array();

	// Для задания псевдонимов "по-умолчанию" переменных с выключенным ЧПУ. Как правило массив пустой
	protected $arDefaultVariableAliases = array();

	// Массив, хранящий значения переменных после обработки запроса
	protected $arVariables = array();
	// Массив, хранящий соответствие переменных псевдонимам после обработки запроса
	protected $arVariableAliases = array();
	// Список всех переменных, которые может принимать компонент из параметров GET запроса
	protected $arAllowedComponentVariables = array('APPLICATION_ID');
	// Имя шаблона, который будет использоваться (можно сразу задать значение по умолчанию)
	protected $componentPage = 'applicationList';

	protected function getResult()
	{
		global $USER;

		if ($this->arParams['SEF_MODE'] == 'Y') {

			// Формируем параметры ЧПУ на основе значений "по-умолчанию" и значений, заданных настройкой компонента
			$this->arUrlTemplates = \CComponentEngine::MakeComponentUrlTemplates(
		    	$this->arDefaultUrlTemplates404,
		    	$this->arParams['SEF_URL_TEMPLATES']
			);

			// Формируем список соответствия имен переменных их псевдонимам
			$this->arVariableAliases = \CComponentEngine::MakeComponentVariableAliases(
				$this->arDefaultVariableAliases404,
				$this->arParams['VARIABLE_ALIASES']
			);

			// Определеяем, какому шаблону пути соответствует запрошенный пользователем URL.
			// Если соответствующий шаблон был найден, то возвращается его код, иначе возвращается пустая строка.
			// В arVariables при этом сохраняется массив значений переменных компонента (без учёта псевдонимов)
		    $this->componentPage = \CComponentEngine::ParseComponentPath(
		        $this->arParams['SEF_FOLDER'],
				$this->arUrlTemplates,
				$this->arVariables
		    );

			// Если ParseComponentPath не нашёл соответствия запрошенному URL и вернул пустую строку,
			// то восстанавливаем значение "по умолчанию"
		    if (strlen($this->componentPage) <= 0) {
		        $this->componentPage = 'applicationList';
			}

			// Заполняем массив arVariables значениями переменных из GET запроса, учитывая заданные псевдонимы.
			// Обрабатываются только те переменные, имена которых перечислены в arAllowedComponentVariables
			CComponentEngine::InitComponentVariables(
				$this->componentPage,
				$this->arAllowedComponentVariables,
				$this->arVariableAliases,
				$this->arVariables
			);

		} else {
//
//			// Супер-метод битрикса, суть которого сводится к merge двух массивов?
//			$this->arVariableAliases = CComponentEngine::MakeComponentVariableAliases(
//				$this->arDefaultVariableAliases,
//				$this->arParams['VARIABLE_ALIASES']
//			);
//
//			// Заполняем массив arVariables значениями переменных из GET запроса, учитывая заданные псевдонимы.
//			// Обрабатываются только те переменные, имена которых перечислены в arAllowedComponentVariables
//			CComponentEngine::InitComponentVariables(
//				false,
//				$this->arAllowedComponentVariables,
//				$this->arVariableAliases,
//				$this->arVariables
//			);
//
//			// Так как ЧПУ выключен, нужно тем или иным образом определить, какой шаблон компонента использовать
//			if (intval($this->arVariables["ELEMENT_ID"]) > 0) {
//				$this->componentPage = 'applicationList';
//			} else {
//				$this->componentPage = 'applicationEdit';
//			}
		}

		$this->arResult = array(
			'FOLDER' => $this->arParams['SEF_FOLDER'],
			'URL_TEMPLATES' => $this->arUrlTemplates,
			'VARIABLES' => $this->arVariables,
			'ALIASES' => $this->arVariableAliases,
		);
	}

	/**
	 * Проверяет, авторизован ли пользователь и относится ли он к группе "абитуриенты". В составных компонентах
	 * комплексного компонента в дальнейшем эта проверка не проводится
	 *
	 * @throws Bitrix\Main\Security\SecurityException
	 */
	private function checkCurrentUser()
	{
		global $USER;
		$currentUserId = $USER->GetID();

		if (empty($currentUserId))
			throw new Main\Security\SecurityException(Loc::getMessage('USER_IS_GUEST'));

		if (!SPOUser::checkIsAbiturient($USER->GetUserGroupArray()))
			throw new Main\Security\SecurityException(Loc::getMessage('USER_IS_NOT_ABITURIENT'));

	}

	protected function checkModules()
	{
		if (!Main\Loader::includeModule('iblock'))
			throw new Main\LoaderException(Loc::getMessage('IBLOCK_MODULE_NOT_INSTALLED'));
	}

	public function executeComponent()
	{
		try {
			$this->checkModules();
			$this->checkCurrentUser();
			$this->getResult();
			$this->includeComponentTemplate($this->componentPage);
		} catch (Exception $e) {
			ShowError($e->getMessage());
		}
	}
}
?>