<?
$MESS['USER_IS_GUEST'] = 'Необходима авторизация';
$MESS['USER_IS_NOT_ABITURIENT'] = 'Текущий пользователь не относится к группе "Абитуриенты"';
$MESS['IBLOCK_MODULE_NOT_INSTALLED'] = 'Модуль "Инфоблоки" не установлен';
?>