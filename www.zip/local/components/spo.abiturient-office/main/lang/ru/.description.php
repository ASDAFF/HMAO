<?
$MESS['STANDARD_ELEMENTS_DESCRIPTION_NAME'] = 'Личный кабинет абитуриента';
$MESS['STANDARD_ELEMENTS_DESCRIPTION_DESCRIPTION'] = 'Компонент, реализующий возможности личного кабинета абитуриета';
$MESS['STANDARD_ELEMENTS_DESCRIPTION_GROUP'] = 'СПО';
$MESS['STANDARD_ELEMENTS_DESCRIPTION_DIR'] = 'Абитуриент';
?>