<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();?>
<?$APPLICATION->IncludeComponent(
	"spo.abiturient-office:application.list",
	"",
	Array(
		"IBLOCK_TYPE" => $arParams['IBLOCK_TYPE'],
		"IBLOCK_ID" => $arParams['IBLOCK_ID'],
		"USER_ID" => $arResult['VARIABLES']['USER_ID'],
	),
$component
);?>