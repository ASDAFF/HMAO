<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die(); ?>
<?$APPLICATION->IncludeComponent(
	"spo.abiturient-office:application.edit",
	"",
	Array(
		"APPLICATION_ID" => $arResult['VARIABLES']['APPLICATION_ID'],
	),
	$component
);?>