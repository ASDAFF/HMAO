<?php

CModule::AddAutoloadClasses(
	'hardfaq.d7example',
	array(
		'Hardfaq\D7Example\Model'           => 'lib/model.php',
		'\Hardfaq\D7Example\Model'          => 'lib/model.php',
	)
);

?>