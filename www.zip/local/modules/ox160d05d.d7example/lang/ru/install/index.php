<?php

$MESS['REFERENCES_INSTALL_TITLE'] = 'Установка модуля "Справочники"';
$MESS['REFERENCES_UNINSTALL_TITLE'] = 'Деинсталляция модуля "Справочники"';

?>