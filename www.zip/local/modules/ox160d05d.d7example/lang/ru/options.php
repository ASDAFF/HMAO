<?php
$MESS['REFERENCES_MAX_IMAGE_SIZE'] = "Максимальный размер изображений (px)";
$MESS['REFERENCES_OPTIONS_RESTORED'] = "Восстановлены настройки по умолчанию";
$MESS['REFERENCES_OPTIONS_SAVED'] = "Настройки сохранены";
$MESS['REFERENCES_INVALID_VALUE'] = "Введено неверное значение";
?>