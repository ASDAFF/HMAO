<?php

$MESS['REFERENCES_ADD_BUTTON'] = 'Добавить';
$MESS['REFERENCES_DELETE_CONFIRM'] = 'Вы уверены, что хотите удалить выбранную запись?';
$MESS['REFERENCES_SAVE_ERROR'] = 'Ошибка сохранения';
$MESS['REFERENCES_DELETE_ERROR'] = 'Ошибка удаления';
$MESS['REFERENCES_IMAGE_ERROR'] = 'Ошибка загрузки изображения';

?>