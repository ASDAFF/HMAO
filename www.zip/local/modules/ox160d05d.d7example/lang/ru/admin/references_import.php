<?php

$MESS['REFERENCES_TAB'] = 'Справочники';
$MESS['REFERENCES_IMPORT_TAB'] = 'Импорт';
$MESS['REFERENCES_IMPORT_SELECT_FILE'] = 'Выберите xml-файл';
$MESS['REFERENCES_IMPORT_UPLOAD'] = 'Загрузить';
$MESS['REFERENCES_UPLOAD_ERROR'] = 'Ошибка загрузки файла';
$MESS['REFERENCES_IMPORT_ERROR_AT_STEP'] = 'В ходе импорта возникли ошибки (шаг: #STEP#, #MESSAGE#)';

?>