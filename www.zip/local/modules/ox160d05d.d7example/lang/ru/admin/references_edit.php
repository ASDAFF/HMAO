<?php

$MESS['REFERENCES_RETURN_TO_LIST_BUTTON'] = 'Вернуться в список';
$MESS['REFERENCES_ADD_PAGE'] = 'Добавление новой записи в справочник';
$MESS['REFERENCES_EDIT_PAGE'] = 'Редактирование записи справочника';
$MESS['REFERENCES_TAB'] = 'Справочник';
$MESS['REFERENCES_IMAGE_ERROR'] = 'Ошибка загрузки изображения';

?>