<?
$MESS["COUNTRY_ENTITY_ID_FIELD"] = "ID";
$MESS["COUNTRY_ENTITY_CODE_FIELD"] = "Уникальный идентификатор";
$MESS["COUNTRY_ENTITY_NAME_RU_FIELD"] = "Название на русском";
$MESS["COUNTRY_ENTITY_NAME_EN_FIELD"] = "Название на английском";
?>