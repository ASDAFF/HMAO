<?
$MESS["AGE_GROUP_ENTITY_ID_FIELD"] = "ID";
$MESS["AGE_GROUP_ENTITY_NAME_RU_FIELD"] = "Название на русском";
$MESS["AGE_GROUP_ENTITY_NAME_EN_FIELD"] = "Название на английском";
?>