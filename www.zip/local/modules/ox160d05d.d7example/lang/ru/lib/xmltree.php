<?php

$MESS["XML_TREE_ID"] = "ID узла";
$MESS["XML_TREE_PARENT_ID"] = "ID родительского узла";
$MESS["XML_TREE_LEFT_MARGIN"] = "Левый отступ узла";
$MESS["XML_TREE_RIGHT_MARGIN"] = "Правый отступ узла";
$MESS["XML_TREE_DEPTH_LEVEL"] = "Уровень вложенности узла";
$MESS["XML_TREE_NAME"] = "Имя узла";
$MESS["XML_TREE_VALUE"] = "Значение узла";
$MESS["XML_TREE_ATTRIBUTES"] = "Атрибуты узла";

?>