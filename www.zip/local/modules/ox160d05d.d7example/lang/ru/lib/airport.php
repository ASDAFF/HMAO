<?
$MESS["AIRPORT_ENTITY_ID_FIELD"] = "ID";
$MESS["AIRPORT_ENTITY_CODE_FIELD"] = "Уникальный идентификатор";
$MESS["AIRPORT_ENTITY_NAME_RU_FIELD"] = "Название на русском";
$MESS["AIRPORT_ENTITY_NAME_EN_FIELD"] = "Название на английском";
$MESS["AIRPORT_ENTITY_CITY_ID_FIELD"] = "Город";
$MESS["AIRPORT_ENTITY_COUNTRY_ID_FIELD"] = "Страна";
$MESS["AIRPORT_ENTITY_CITY_FIELD"] = "Город";
$MESS["AIRPORT_ENTITY_COUNTRY_FIELD"] = "Страна";
$MESS["AIRPORT_ENTITY_COORDINATES_FIELD"] = "Географические координаты";
?>