<?
$MESS["SUBOFFER_ENTITY_ID_FIELD"] = "ID";
$MESS["SUBOFFER_ENTITY_NAME_RU_FIELD"] = "Название на русском";
$MESS["SUBOFFER_ENTITY_NAME_EN_FIELD"] = "Название на английском";
$MESS["SUBOFFER_ENTITY_PARENT_ID_FIELD"] = "Родительское направление";
$MESS["SUBOFFER_ENTITY_PARENT_FIELD"] = "Родительское направление";
?>