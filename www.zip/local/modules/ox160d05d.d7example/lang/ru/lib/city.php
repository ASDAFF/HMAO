<?
$MESS["CITY_ENTITY_ID_FIELD"] = "ID";
$MESS["CITY_ENTITY_CODE_FIELD"] = "Уникальный идентификатор";
$MESS["CITY_ENTITY_NAME_RU_FIELD"] = "Название на русском";
$MESS["CITY_ENTITY_NAME_EN_FIELD"] = "Название на английском";
$MESS["CITY_ENTITY_COUNTRY_ID_FIELD"] = "Страна";
$MESS["CITY_ENTITY_COUNTRY_FIELD"] = "Страна";
?>