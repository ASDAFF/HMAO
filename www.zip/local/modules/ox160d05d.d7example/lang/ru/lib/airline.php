<?
$MESS["AIRLINE_ENTITY_ID_FIELD"] = "ID";
$MESS["AIRLINE_ENTITY_CODE_FIELD"] = "Уникальный идентификатор";
$MESS["AIRLINE_ENTITY_NAME_RU_FIELD"] = "Название на русском";
$MESS["AIRLINE_ENTITY_NAME_EN_FIELD"] = "Название на английском";
$MESS["AIRLINE_ENTITY_IMAGE_FIELD"] = "Изображение";
$MESS["AIRLINE_ENTITY_ALLIANCE_ID_FIELD"] = "Альянс";
$MESS["AIRLINE_ENTITY_ALLIANCE_FIELD"] = "Альянс";
?>