<?php

$MESS["IMPORT_XML_FILE_IS_REQUIRED"] = "Не указан обязательный параметр \"xml_file\"";
$MESS["IMPORT_DROP_TABLES"] = "Удаление временной таблицы";
$MESS["IMPORT_TABLE_CREATE"] = "Создание новой временной таблицы";
$MESS["IMPORT_FILE"] = "Загрузка xml-файла во временную таблицу";
$MESS["IMPORT_INDEX"] = "Индексация временной таблицы";
$MESS["IMPORT_INSERT_INTO_REFERENCE"] = "Загрузка данных в справочник";
$MESS["IMPORT_FINISHED"] = "Импорт завершен<br>Добавлено: #INSERTED#<br>Обновлено: #UPDATED#";
$MESS["IMPORT_FILE_ERROR"] = "Файл не существует или недоступен для чтения";
$MESS["IMPORT_INSERT_CITY_ERROR"] = "Город с уникальным идентификатором \"#CODE#\" отсутсвует в справочнике городов";
$MESS["IMPORT_INSERT_COUNTRY_ERROR"] = "Страна с уникальным идентификатором  \"#CODE#\" отсутсвует в справочнике стран";
$MESS["IMPORT_INSERT_ERROR"] = "Ошибка добавления записи в справочник";
$MESS["IMPORT_UPDATE_ERROR"] = "Ошибка обновления записи в справочнике";
$MESS["IMPORT_XML_ERROR"] = "Неверный формат xml-файла";

?>