<?
$nota_references_default_option = array(
	"max_image_size" => "500",
);
?>