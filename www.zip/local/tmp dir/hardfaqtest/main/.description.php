<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

use \Bitrix\Main\Localization\Loc as Loc;

Loc::loadMessages(__FILE__);

$arComponentDescription = array(
	"NAME" => Loc::getMessage('STANDARD_ELEMENTS_DESCRIPTION_NAME'),
	"DESCRIPTION" => Loc::getMessage('STANDARD_ELEMENTS_DESCRIPTION_DESCRIPTION'),
	"ICON" => '/images/icon.gif',
	"SORT" => 10,
	"PATH" => array(
		"ID" => 'hardfaq2',
		"NAME" => Loc::getMessage('STANDARD_ELEMENTS_DESCRIPTION_GROUP'),
		"SORT" => 10,
		// Раздел CHILD можно использовать, чтобы логически сгруппировать компоненты по разделам в админке.
		"CHILD" => array(
			"ID" => 'somesection3',
			"NAME" => Loc::getMessage('STANDARD_ELEMENTS_DESCRIPTION_DIR'),
			"SORT" => 10
		)
	),
	'COMPLEX' => 'Y',
);

?>