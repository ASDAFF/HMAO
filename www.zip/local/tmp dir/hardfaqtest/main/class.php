<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

class MainComponent extends \CBitrixComponent
{

	// Для задания путей "по-умолчанию" для работы в ЧПУ режиме
	protected $arDefaultUrlTemplates404 = array(
		'index' => 'mycomponent',
		'detail' => 'mycomponent/#ELEMENT_ID#/',
	);

	// Для задания псевдонимов "по-умолчанию" переменных в режиме ЧПУ. Как правило массив пустой
	protected $arDefaultVariableAliases404 = array();

	protected $arUrlTemplates = array();

	// Для задания псевдонимов "по-умолчанию" переменных с выключенным ЧПУ. Как правило массив пустой
	protected $arDefaultVariableAliases = array();

	// Массив, хранящий значения переменных после обработки запроса
	protected $arVariables = array();
	// Массив, хранящий соответствие переменных псевдонимам после обработки запроса
	protected $arVariableAliases = array();
	// Список всех переменных, которые может принимать компонент из параметров GET запроса
	protected $arAllowedComponentVariables = array('ELEMENT_ID', 'PARAM1', 'PARAM2');
	// Имя шаблона, который будет использоваться (можно сразу задать значение по умолчанию)
	protected $componentPage = 'index';

	protected function getResult()
	{
		if ($this->arParams['SEF_MODE'] == 'Y') {

			// Формируем параметры ЧПУ на основе значений "по-умолчанию" и значений, заданных настройкой компонента
			$this->arUrlTemplates = \CComponentEngine::MakeComponentUrlTemplates(
		    	$this->arDefaultUrlTemplates404,
		    	$this->arParams['SEF_URL_TEMPLATES']
			);

			// Формируем список соответствия имен переменных их псевдонимам
			$this->arVariableAliases = \CComponentEngine::MakeComponentVariableAliases(
				$this->arDefaultVariableAliases404,
				$this->arParams['VARIABLE_ALIASES']
			);

			// Определеяем, какому шаблону пути соответствует запрошенный пользователем URL.
			// Если соответствующий шаблон был найден, то возвращается его код, иначе возвращается пустая строка.
			// В arVariables при этом сохраняется массив значений переменных компонента (без учёта псевдонимов)
		    $this->componentPage = \CComponentEngine::ParseComponentPath(
		        $this->arParams['SEF_FOLDER'],
				$this->arUrlTemplates,
				$this->arVariables
		    );

			// Если ParseComponentPath не нашёл соответствия запрошенному URL и вернул пустую строку,
			// то восстанавливаем значение "по умолчанию"
		    if (strlen($this->componentPage) <= 0) {
		        $this->componentPage = 'index';
			}

			// Заполняем массив arVariables значениями переменных из GET запроса, учитывая заданные псевдонимы.
			// Обрабатываются только те переменные, имена которых перечислены в arAllowedComponentVariables
			CComponentEngine::InitComponentVariables(
				$this->componentPage,
				$this->arAllowedComponentVariables,
				$this->arVariableAliases,
				$this->arVariables
			);

		} else {

			// Супер-метод битрикса, суть которого сводится к merge двух массивов
			$this->arVariableAliases = CComponentEngine::MakeComponentVariableAliases(
				$this->arDefaultVariableAliases,
				$this->arParams['VARIABLE_ALIASES']
			);

			// Заполняем массив arVariables значениями переменных из GET запроса, учитывая заданные псевдонимы.
			// Обрабатываются только те переменные, имена которых перечислены в arAllowedComponentVariables
			CComponentEngine::InitComponentVariables(
				false,
				$this->arAllowedComponentVariables,
				$this->arVariableAliases,
				$this->arVariables
			);

			// Так как ЧПУ выключен, нужно тем или иным образом определить, какой шаблон компонента использовать
			if (intval($this->arVariables["ELEMENT_ID"]) > 0) {
				$this->componentPage = 'detail';
			} else {
				$this->componentPage = 'index';
			}
		}

		$this->arResult = array(
			'FOLDER' => $this->arParams['SEF_FOLDER'],
			'URL_TEMPLATES' => $this->arUrlTemplates,
			'VARIABLES' => $this->arVariables,
			'ALIASES' => $this->arVariableAliases,
		);
	}

	public function executeComponent()
	{
		try {
			$this->getResult();
			$this->includeComponentTemplate($this->componentPage);
		} catch (Exception $e) {
			ShowError($e->getMessage());
		}
	}
}
?>