<?
$MESS['STANDARD_ELEMENTS_DESCRIPTION_NAME'] = 'Комплексный компонент';
$MESS['STANDARD_ELEMENTS_DESCRIPTION_DESCRIPTION'] = 'Стандартный комплексный компонент для отображения списка элементов и элемента детально';
$MESS['STANDARD_ELEMENTS_DESCRIPTION_GROUP'] = 'hardfaq';
$MESS['STANDARD_ELEMENTS_DESCRIPTION_DIR'] = 'Стандартные компоненты';
?>