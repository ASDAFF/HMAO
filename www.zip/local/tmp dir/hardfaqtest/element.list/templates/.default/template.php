<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die(); ?>
<?
use \Bitrix\Main\Localization\Loc as Loc;
Loc::loadMessages(__FILE__);
?>

<? if (count($arResult['ITEMS'])):?>
<h3><?=Loc::getMessage('STANDARD_ELEMENTS_LIST_TEMPLATE_TITLE');?></h3>
<? foreach ($arResult['ITEMS'] as $item):?>
<div>
<div><strong><?=$item['DATE'];?></strong> <a href="/сюда ссылку-какую-то"><?=$item['NAME'];?></a></div>
<div><?=$item['TEXT'];?></div>
</div>
<? endforeach;?>
<?=$arResult['NAV_STRING'];?>
<? endif;?>
