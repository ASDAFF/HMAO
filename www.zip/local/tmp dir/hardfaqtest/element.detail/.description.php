<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => 'Элемент',
	"DESCRIPTION" => 'Стандартный компонент для отображения одного элемента',
	"ICON" => '/images/icon.gif',
	"SORT" => 20,
	"PATH" => array(
		"ID" => 'hardfaq',
		"NAME" => 'hardfaq',
		"SORT" => 10,
		"CHILD" => array(
			"ID" => 'somesection',
			"NAME" => 'Стандартные компоненты',
			"SORT" => 10
		)
	),
);