<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

use \Bitrix\Main;
use \Bitrix\Main\Localization\Loc as Loc;

class ElementDetailComponent extends CBitrixComponent
{

	protected function checkModules()
	{
		if (!Main\Loader::includeModule('iblock'))
			throw new Main\LoaderException('Модуль "Инфоблоки" не установлен');
	}

	protected function checkParams()
	{
		if ($this->arParams['IBLOCK_ID'] <= 0)
			throw new Main\ArgumentNullException('IBLOCK_ID');
	}

	protected function getResult()
	{
		$this->arResult['ELEMENT_ID'] = $this->arParams['ELEMENT_ID'];
		// Знаем ID запрошенного элемента, нужно делать запрос к инфоблокам, вытягивать нужное, передавать...

		return $this->arResult;
	}

	public function executeComponent()
	{
		try {
			$this->checkModules();
			$this->checkParams();
			$this->getResult();
			$this->includeComponentTemplate();
		} catch (Exception $e) {
			$this->abortDataCache();
			ShowError($e->getMessage());
		}
	}
}
?>