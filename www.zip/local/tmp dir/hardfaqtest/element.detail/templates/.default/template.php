<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die(); ?>
<?
use \Bitrix\Main\Localization\Loc as Loc;
Loc::loadMessages(__FILE__);
?>

<h3>Детальный просмотр элемента</h3>
Выбран элемент с ID: <?= $arParams['ELEMENT_ID'] ?>


