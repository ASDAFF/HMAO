<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

use \Bitrix\Main\Localization\Loc as Loc;

Loc::loadMessages(__FILE__);

$arComponentDescription = array(
	"NAME" => 'Резюме и вакансии',
	"DESCRIPTION" => 'Комплексный компонент для отображения списка резюме и вакансий',
	"ICON" => '/images/icon.gif',
	"SORT" => 10,

	// Массив PATH для настройки отображения компонента в списке компонентов (в админке). Если не задавать - компоненты
	// не будет отображён в дереве выбора компонентов
	"PATH" => array(
		"ID" => 'Заявки', // Название главной группы (content, e-store и др. могут быть зарезервированы)
		"SORT" => 10,
		// Раздел CHILD можно использовать, чтобы логически сгруппировать компоненты по разделам в админке.
		"CHILD" => array(
			"ID" => 'requestsGroupId',
			"NAME" => 'Резюме и вакансии',
			"SORT" => 10
		)
	),
	'COMPLEX' => 'Y',
);

?>