<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

use \Bitrix\Main;

try
{
	if (!Main\Loader::includeModule('iblock'))
		throw new Main\LoaderException('Модуль "Инфоблоки" не установлен');
	
	$iblockTypes = \CIBlockParameters::GetIBlockTypes(array('-' => ' '));
	
	$iblocks = array(0 => " ");
	if (isset($arCurrentValues['IBLOCK_TYPE']) && strlen($arCurrentValues['IBLOCK_TYPE']))
	{
	    $filter = array(
	        'TYPE' => $arCurrentValues['IBLOCK_TYPE'],
	        'ACTIVE' => 'Y'
	    );
	    $rsIBlock = \CIBlock::GetList(array('SORT' => 'ASC'), $filter);
	    while ($arIBlock = $rsIBlock->GetNext()) {
	        $iblocks[$arIBlock['ID']] = $arIBlock['NAME'];
	    }
	}
	
	$sortFields = array(
		'ID' => 'ID',
		'NAME' => 'Название',
		'ACTIVE_FROM' => 'Дата начала активности',
		'SORT' => 'Индекс сортировки',
	);
	
	$sortDirection = array(
		'ASC' => 'По возрастанию',
		'DESC' => 'По убыванию',
	);
	
	$arComponentParameters = array(
		'GROUPS' => array(
		),
		'PARAMETERS' => array(
			'IBLOCK_TYPE' => Array(
				'PARENT' => 'BASE',
				'NAME' => 'Тип инфоблока',
				'TYPE' => 'LIST',
				'VALUES' => $iblockTypes,
				'DEFAULT' => '',
				'REFRESH' => 'Y'
			),
			'IBLOCK_ID' => array(
				'PARENT' => 'BASE',
				'NAME' => 'Инфоблок',
				'TYPE' => 'LIST',
				'VALUES' => $iblocks
			),
			'SHOW_NAV' => array(
				'PARENT' => 'BASE',
				'NAME' => 'Постраничная навигация',
				'TYPE' => 'CHECKBOX',
				'DEFAULT' => 'N'
			),
			'COUNT' =>  array(
				'PARENT' => 'BASE',
				'NAME' => 'Количество элементов',
				'TYPE' => 'STRING',
				'DEFAULT' => '5'
			),
			'SEF_MODE' => array(
	            'index' => array(
	                'NAME' => 'Страница со списком элементов',
	                'DEFAULT' => 'index.php',
	                'VARIABLES' => array()
	            ),
	            'detail' => array(
	            	"NAME" => 'Страница с детальным описанием элемента',
	                "DEFAULT" => 'detail/#ELEMENT_ID#/',
	                "VARIABLES" => array('ELEMENT_ID')
				)
	        ),
			'CACHE_TIME' => array(
				'DEFAULT' => 3600
			)
		)
	);
}
catch (Main\LoaderException $e)
{
	ShowError($e->getMessage());
}
?>