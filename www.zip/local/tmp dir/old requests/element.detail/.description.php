<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => 'Элемент',
	"DESCRIPTION" => 'Стандартный компонент для отображения одного элемента',
	"ICON" => '/images/icon.gif',
	"SORT" => 20,
	"PATH" => array(
		// Входит в состав комплексного компонента, отображать отделньо для выбора не нужно, поэтому пустой массив
	),
);