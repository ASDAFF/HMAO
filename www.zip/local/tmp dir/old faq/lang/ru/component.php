<? $MESS["YIITMESSAGE3"] = "Текст с переводом - русская версия - component.php компонента";?>


