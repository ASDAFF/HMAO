<?php if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();


class CFaq extends CBitrixComponent
{
	// Родительский метод проходит по всем параметрам, переданным в $APPLICATION->IncludeComponent и применяет к ним
	// функцию htmlspecialcharsex. В данном случае такая обработка избыточна, и её можно переопределить
	// по факту, пока что не вижу влияния
	public function onPrepareComponentParams($arParams)
	{
		return $arParams;
	}

	public function getPreparedArResult($unpreparedArray)
	{
		$result = array();

		foreach ($unpreparedArray as $element) {
			$result[] = array(
				"id" => $element['ID'],
				"code" => $element['CODE'],
				"name" => $element['NAME'],
				"count" => $element['ELEMENT_CNT']
			);
		}

		return $result;
	}

}