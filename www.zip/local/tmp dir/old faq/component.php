<?php if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

use \Bitrix\Main\Localization\Loc as Loc;

// Можно подгрузить сообщения, указав конкретный файл компонента (в данном случае - из lang/ru/class.php)
Loc::loadMessages(__DIR__ . '\class.php');
echo Loc::getMessage('YIITMESSAGE2') . '<br>';

// Можно подгрузить сообщения для текущего файла (в данном случае - из lang/ru/component.php)
Loc::loadMessages(__FILE__);
echo Loc::getMessage('YIITMESSAGE3') . '<br>';

if (!CModule::IncludeModule('iblock')) {
	die('Модуль информационных блоков не установлен');
};


if ($this->StartResultCache(3600)) {

	$iBlockName = $arParams['IBLOCK_TYPE'];
	$arFilter = array('IBLOCK_TYPE' => $iBlockName);

	$sectionsList = CIBlockSection::GetList(
		array('NAME'=>'ASC'),
		$arFilter,
		true,
		array("ID", "NAME", "CODE")
	);

	while ($result = $sectionsList->GetNext()) {
		$arResult[] = $result;
	}

	// Вызываем метод из class.php данного модуля
	$arResult = $this->getPreparedArResult($arResult);

	$this->IncludeComponentTemplate();
}
?>