<?php if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

$arComponentDescription = array(
	'NAME' => 'FAQ',
	'DESCRIPTION' => 'Вопросы и ответы',
	//'ICON' => '/images/icon.gif',
	'CACHE_PATH' => 'Y',
	'PATH' => array(
		'ID' => 'utility',
	),
);