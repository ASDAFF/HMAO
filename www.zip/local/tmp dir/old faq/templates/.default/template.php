<?php

// сообщение берётся из COMPONENT_ID\templates\.default\lang\ru\template.php
echo GetMessage("YIITMESSAGE") . '<hr>';

Vardumper::dump($arResult);

foreach($arResult as $category) {
	echo $category['name'] . '(' . $category['count'] . ')</br>';
}

?>