<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("COMPONENT_RF_MAP_NAME"),
	"DESCRIPTION" => GetMessage("COMPONENT_RF_MAP_DESC"),
	"ICON" => "/images/news_list.gif",
	"SORT" => 20,
	"CACHE_PATH" => "Y",
	"PATH" => array(
		"ID" => "content",
		"CHILD" => array(
			"ID" => "RF-imap",
			"NAME" => GetMessage("COMPONENT_RF_MAP_NAME_DETAIL"),
			"SORT" => 10
		)
	),
);

?>