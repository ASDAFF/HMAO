<?
   if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

   $json_data = Array();
   foreach($arResult["ITEMS"] as $district)
   {

	   $json_data[$district["CODE"]] = Array(
		   "title" => $district["NAME"]
	   );

	   foreach($district["REPRESENTATIONS"] as $repr)
	   {


		   // Обрабатываем полуфинальные мероприятия
		   $events = Array();
		   foreach($repr["REPRESENTATION_SEMIFINALS"] as $event)
		   {
			   $events[] = Array(
				   "nomination_info" => $event["PROPERTY_COMPETITION_NOMINATION_VALUE"],
				   "label" => $event["NAME"],
				   "date" => Array("date" => CIBlockFormatProperties::DateFormat('j F Y', MakeTimeStamp($event["PROPERTY_EVENT_DATE_VALUE"], CSite::GetDateFormat())), "timestamp" => MakeTimeStamp($event["PROPERTY_EVENT_DATE_VALUE"], CSite::GetDateFormat()))
			   );
		   }

		   if($repr["PROPERTY_REPRESENTATION_KONKURS_SID_VALUE"])
			   $konkurs_sid = $repr["PROPERTY_REPRESENTATION_KONKURS_SID_VALUE"];
			else
			   $konkurs_sid = $repr["PROPERTY_REPRESENTATION_REGION_VALUE"];

		   //EXTERNAL_ID - site_global_id
		   $rec = Array(
			   "label" => ($repr["REPRESENTATION_REGION"] !== null ? $repr["REPRESENTATION_REGION"]["UF_NAME"] : ''),
			   "representation_title" => $repr["NAME"],
			   "final_event_title" => $repr["PROPERTY_REPRESENTATION_FINAL_EVENT_VALUE"],
			   "site" =>  "",
			   "status" => $repr["PROPERTY_STATUS_VALUE"], //(array_key_exists('STATUS', $props) ? $props["STATUS"]["DISPLAY_VALUE"] : ""),
			   "date" => Array(
				   "start" => ( $repr["PROPERTY_APPLIANCE_START_VALUE"] ? Array("date" => CIBlockFormatProperties::DateFormat('j F Y', MakeTimeStamp($repr["PROPERTY_APPLIANCE_START_VALUE"], CSite::GetDateFormat())), "timestamp" => MakeTimeStamp($repr["PROPERTY_APPLIANCE_START_VALUE"], CSite::GetDateFormat())) : null ),
				   "end" => ( $repr["PROPERTY_APPLIANCE_END_VALUE"] ? Array("date" => CIBlockFormatProperties::DateFormat('j F Y', MakeTimeStamp($repr["PROPERTY_APPLIANCE_END_VALUE"], CSite::GetDateFormat())), "timestamp" => MakeTimeStamp($repr["PROPERTY_APPLIANCE_END_VALUE"], CSite::GetDateFormat())) : null ),
				   "final" => ( $repr["PROPERTY_FINAL_EVENT_VALUE"] ? Array("date" => CIBlockFormatProperties::DateFormat('j F Y', MakeTimeStamp($repr["PROPERTY_FINAL_EVENT_VALUE"], CSite::GetDateFormat())), "timestamp" => MakeTimeStamp($repr["PROPERTY_FINAL_EVENT_VALUE"], CSite::GetDateFormat())) : null ),
			   ),
			   "events" => $events,
			   "city" => $repr["PROPERTY_EVENT_CITY_VALUE"], // (array_key_exists('EVENT_CITY', $props) ? $props["EVENT_CITY"]["DISPLAY_VALUE"] : ""),
			   "agent" => $repr["PROPERTY_FIO_REPRESENTATIVE_VALUE"], // (array_key_exists('FIO_REPRESENTATIVE', $props) ? $props["FIO_REPRESENTATIVE"]["DISPLAY_VALUE"] : ""),
			   "x" => $repr["PROPERTY_REPRESENTATION_LAYOUT_X_VALUE"],
			   "y" => $repr["PROPERTY_REPRESENTATION_LAYOUT_Y_VALUE"],
			   "info" => $repr["PROPERTY_REPRESENTATION_INFO_VALUE"], // (array_key_exists('REPRESENTATION_INFO', $props) ? $props["REPRESENTATION_INFO"]["DISPLAY_VALUE"] : "")
			   "adress" => $repr["PROPERTY_REPRESENTATION_ADRESS_VALUE"],
			   "telephone" => $repr["PROPERTY_REPRESENTATION_TELEPHONE_VALUE"],
			   "email" => $repr["PROPERTY_REPRESENTATION_EMAIL_VALUE"],
			   "alt_view" => $repr["PROPERTY_REPRESENTATION_ALTERNATIVE_VIEW_VALUE"],
			   "konkurs_sid" => $konkurs_sid,
			   "is_not_connected" => $repr["PROPERTY_REPRESENTATION_IS_NOT_CONNECTED_VALUE"]
		   );

		   if(!array_key_exists($repr["PROPERTY_REPRESENTATION_REGION_VALUE"], $json_data[$district["CODE"]]))
		   {
			   $json_data[$district["CODE"]][$repr["PROPERTY_REPRESENTATION_REGION_VALUE"]] = $rec;
		   }
		   else
		   {
			   if(!is_array($json_data[$district["CODE"]][$repr["PROPERTY_REPRESENTATION_REGION_VALUE"]][0]))
			   {
				   $json_data[$district["CODE"]][$repr["PROPERTY_REPRESENTATION_REGION_VALUE"]] = Array($json_data[$district["CODE"]][$repr["PROPERTY_REPRESENTATION_REGION_VALUE"]]);
			   }

			   $json_data[$district["CODE"]][$repr["PROPERTY_REPRESENTATION_REGION_VALUE"]][] = $rec;
		   }
	   }
   }


   $json_data_region = Array();
   foreach($arResult["REGIONS"] as $region_id => $region)
   {
	   $json_data_region[$region_id] = $region["UF_NAME"];
   }

?>

<script type="text/javascript">
var map_data = <? echo json_encode($json_data); ?>;
var region_data = <? echo json_encode($json_data_region); ?>;
</script>


