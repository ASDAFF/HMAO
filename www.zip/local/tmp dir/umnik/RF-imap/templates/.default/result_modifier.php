<?
   $arMsk = Array(
	   "CODE" => 'MSK',
	   "NAME" => 'Москва',
	   "REPRESENTATIONS" => Array()
   );

   // Делаем Москву отдельным ФО
   foreach($arResult["ITEMS"] as &$district) 
   {
	   if($district["CODE"] === 'CFO')
	   {
		   $new_cfo = Array();
		   foreach($district["REPRESENTATIONS"] as $repr) 
		   {
			   if($repr["PROPERTY_REPRESENTATION_REGION_VALUE"] === 'moskva')
			   {
				   $arMsk["REPRESENTATIONS"][] = $repr;
			   }
			   else 
			   {
				   $new_cfo[] = $repr;
			   }
		   }

		   $district["REPRESENTATIONS"] = $new_cfo;
	   }
   }

$arResult["ITEMS"][] = $arMsk;

?>