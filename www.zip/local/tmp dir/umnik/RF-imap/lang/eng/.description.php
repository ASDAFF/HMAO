<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$MESS ['COMPONENT_RF_MAP_NAME'] = 'Interactive RF map';
$MESS ['COMPONENT_RF_MAP_DESC'] = 'Navigation by regional sites of competition selections';
$MESS ['COMPONENT_RF_MAP_NAME_DETAIL'] = 'Interactive RF map. Representatives of UMNIK program';

?>