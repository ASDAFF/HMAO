<?

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$MESS ['COMPONENT_RF_MAP_NAME'] = 'Навигация по региональным сайтам отборов';
$MESS ['COMPONENT_RF_MAP_DESC'] = 'Интерактивная карта РФ. Представительства';
$MESS ['COMPONENT_RF_MAP_NAME_DETAIL'] = 'Интерактивная карта РФ';

?>