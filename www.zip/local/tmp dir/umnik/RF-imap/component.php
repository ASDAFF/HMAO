<? 

$arParams['REPRESENTATION_IBLOCK_ID'] = 11;
$arParams['SEMIFINAL_EVENT_IBLOCK_ID'] = 12;
$arParams['REGION_HLBLOCK_ID'] = 1;

if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();


// Проверка загруженных модулей
$requiredModules = array('highloadblock', 'iblock');
foreach ($requiredModules as $requiredModule)
{
   if (!CModule::IncludeModule($requiredModule))
   {
	   ShowError(GetMessage("F_NO_MODULE"));
	   return 0;
   }
}

use Bitrix\Highloadblock as HL;
use Bitrix\Main\Entity;

//$hlblock_id = $arParams['BLOCK_ID'];
$hlblock_region = HL\HighloadBlockTable::getById($arParams['REGION_HLBLOCK_ID'])->fetch();
if (empty($hlblock_region))
{
	// TODO заменить на актуальное сообщение! 
   ShowError('404');
   return 0;
}

$region_entity = HL\HighloadBlockTable::compileEntity($hlblock_region);

$region_query = new Entity\Query($region_entity);
$region_query->setSelect(array('*'));
$region_query->setOrder(array('ID' => 'DESC'));

$region_query_result = $region_query->exec();
$region_db_result = new CDBResult($region_query_result);

$arMapRegion = Array();
while ($row = $region_db_result->Fetch())
{
   $arMapRegion[$row['UF_XML_ID']] = $row;
}

// UF_XML_ID - объединять с PROPERTY_REPRESENTATION_REGION_VALUE

   // Загружаем разделы инфоблока "Региональные представительства"
//if ( CModule::IncludeModule("iblock") )
// { 

	   // Список полуфинальных мероприятий
	   $rsElementEvent = CIBlockElement::GetList(
		   Array("ID"=>"ASC"),
		   Array(
			   "ACTIVE" => 'Y',
			   "IBLOCK_ID" => $arParams['SEMIFINAL_EVENT_IBLOCK_ID'],
			   "IBLOCK_LID" => SITE_ID,
			   "CHECK_PERMISSIONS" => "Y"
		   ),
		   false,
		   false,
		   Array(
			   "ID",
			   "IBLOCK_ID",
			   "XML_ID",
			   "NAME",
			   "PROPERTY_COMPETITION_NOMINATION",
			   "PROPERTY_EVENT_DATE",
			   "PROPERTY_REGION_REPRESENTATION",
		   )
	   );

	   $arMapEvent = array();
	   while($obElement = $rsElementEvent->GetNextElement()) 
	   {

		   $arItem = $obElement->GetFields();
		   $arMapEvent[$arItem["PROPERTY_REGION_REPRESENTATION_VALUE"]][] = $arItem;
	   }
	   // echo mydump($arMapEvent);


	   // Список представительств
	   $rsElement = CIBlockElement::GetList(
		   Array("ID"=>"ASC"),
		   Array(
			   "ACTIVE" => 'Y',
			   "IBLOCK_ID" => $arParams['REPRESENTATION_IBLOCK_ID'],
			   "IBLOCK_LID" => SITE_ID,
			   "CHECK_PERMISSIONS" => "Y"
		   ),
		   false,
		   false,
		   Array(
			   "ID",
			   "IBLOCK_ID",
			   "XML_ID",
			   "NAME",
			   "IBLOCK_TYPE_ID",
			   "IBLOCK_CODE",
			   "IBLOCK_SECTION_ID",
			   "DETAIL_PAGE_URL",
			   "LIST_PAGE_URL",
			   "PROPERTY_STATUS",
			   "PROPERTY_APPLIANCE_START",
			   "PROPERTY_APPLIANCE_END",
			   "PROPERTY_FINAL_EVENT",
			   "PROPERTY_EVENT_CITY",
			   "PROPERTY_FIO_REPRESENTATIVE",
			   "PROPERTY_REPRESENTATION_INFO",
			   "PROPERTY_REPRESENTATION_REGION",
			   "PROPERTY_REPRESENTATION_LAYOUT_X",
			   "PROPERTY_REPRESENTATION_LAYOUT_Y",
			   "PROPERTY_REPRESENTATION_SEMIFINALS",
			   "PROPERTY_REPRESENTATION_ADRESS",
			   "PROPERTY_REPRESENTATION_TELEPHONE",
			   "PROPERTY_REPRESENTATION_EMAIL",
			   "PROPERTY_REPRESENTATION_FINAL_EVENT",
			   "PROPERTY_REPRESENTATION_ALTERNATIVE_VIEW",
			   "PROPERTY_REPRESENTATION_KONKURS_SID",
			   "PROPERTY_REPRESENTATION_IS_NOT_CONNECTED"
		   )
	   );

	   $arRepresentation = Array();
	   while($obElement = $rsElement->GetNextElement()) 
	   {

		   $arItem = $obElement->GetFields();
		   if(array_key_exists($arItem["ID"], $arMapEvent)) 
		   {
			   $arItem["REPRESENTATION_SEMIFINALS"] = $arMapEvent[$arItem["ID"]];
		   }
		   else 
		   {
			   $arItem["REPRESENTATION_SEMIFINALS"] = Array();
		   }

		   $region_xml_id = $arItem["PROPERTY_REPRESENTATION_REGION_VALUE"];
		   if(array_key_exists($region_xml_id, $arMapRegion)) 
		   {
			   $arItem["REPRESENTATION_REGION"] = $arMapRegion[$region_xml_id];
		   }
		   else
		   {
			   $arItem["REPRESENTATION_REGION"] = null;
		   }

		   $arRepresentation[] = $arItem;
	   }

	   // Федеральные округа
	   $rsSection = CIBlockSection::GetList(
		   Array(
			   "ID"=>"ASC"
		   ),
		   Array(
			   "IBLOCK_ID" => $arParams['REPRESENTATION_IBLOCK_ID'],
			   "GLOBAL_ACTIVE " => 'Y',
			   "IBLOCK_ACTIVE" => 'Y'
		   )
	   );

	   $arResult = Array(
		   "ITEMS" => Array(),
		   "REGIONS" => $arMapRegion
	   );
	   while($arDistrict = $rsSection->GetNext()) 
	   {
		   $arDistrict["REPRESENTATIONS"] = Array();
		   foreach($arRepresentation as $repr) 
		   {
			   if($arDistrict["ID"] === $repr["IBLOCK_SECTION_ID"]) 
			   {
				   $arDistrict["REPRESENTATIONS"][] = $repr;
			   }
		   }

		   $arResult["ITEMS"][] = $arDistrict;
	   }


	   if(array_key_exists('DEBUG', $arParams) && $arParams["DEBUG"])
	   {
		   echo mydump($arResult);
	   }
	   //echo mydump($arResult);

	   //$ipropValues = new \Bitrix\Iblock\InheritedProperty\ElementValues($arParams["IBLOCK_ID"], $arRepresentation["ID"]);
	   //   }
//else
	   //   {
	   //   ShowError(GetMessage("IBLOCK_MODULE_NOT_INSTALLED"));
	   //}




$this->IncludeComponentTemplate();

?>