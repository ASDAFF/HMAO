<?php

class KonkursAPI {

	private $publicKey = 'ZNxQoMNZhuLYNEgUN5jXo3Qgc39KK8jcZdr7JsMHZQ8jzqcn';
	private $privateKey = 'ExZuoQfPfqaPxRecjJ4_qYyryT2A7t7JBeM9XaGSV9sEsNjS';
	private $httpLogin = 'devel';
	private $httpPassword = 'VbG3DszQ2lk';
	private $apiServerUrl = '89.249.26.75:3340/';
	private $apiAction = '';

	public $error = false;

	public function __construct($action)
	{
		$this->apiAction = $action;
	}

	public function sendRequest($data = array())
	{
		if (!function_exists('curl_version')) {
			$this->error = 'Для корректной работы необходимо установить cURL - https://php.net/curl';
			return null;
		}

		$data = \Bitrix\Main\Web\Json::encode($data);
		$checksum = sha1($this->privateKey . $data);
		$params = array('data' => $data, 'key' => $this->publicKey, 'sum' => $checksum);
		$params = http_build_query($params);

		$response = $this->file_get_contents_curl($this->apiServerUrl . $this->apiAction . '?APP_ID=api&' . $params);

		if ($this->error)
			return null;

		try {
			$response = \Bitrix\Main\Web\Json::decode($response);
		} catch(Exception $e) {
			$this->error = 'Ошибка при парсинге JSON: ' . $response;
			return null;
		}

		if (!$response['success']) {
			$this->error = 'Ошибка: ' . $response['message'];
			return null;
		}

		return $response['message'];
	}

	private function file_get_contents_curl($url) {
		$ch = curl_init();

		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_USERPWD, $this->httpLogin . ":" . $this->httpPassword);

		$data = curl_exec($ch);

		$lastResponseCode = curl_getinfo($ch, CURLINFO_HTTP_CODE );

		switch ($lastResponseCode) {
			case 0:
				$this->error = 'Удалённый адрес недоступен: ' . $url;
				break;
			case 401:
				$this->error = 'Ошибка авторизации: ' . $url;
				break;
			case 200:
				break;
			default:
				$this->error = 'Неизвестная ошибка при соединении с ' . $url;
				break;
		}

		curl_close($ch);

		return $data;
	}

} 