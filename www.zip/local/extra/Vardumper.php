<?php

class Vardumper
{
	public static function dump($var, $die = false, $all = false)
	{
		global $USER;
		if (($USER->GetID() == 1) || ($all)) {
		?>
			<p style="text-align: left; font-size: 10px;"><pre><?var_dump($var)?></pre></p><hr>
		<?
		}

		if ($die) {
			die;
		}
	}
}