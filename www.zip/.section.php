<?
$sSectionName = 'Главная';
$arDirProperties = array(
	'title' => 'Региональный портал СПО',
	'description' => 'Региональный портал СПО (Описание)',
	'keywords' => 'Региональный портал СПО (Ключевые слова)',
	'robots' => 'index, follow'
);
?>