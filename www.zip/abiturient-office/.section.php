<?
$sSectionName = "abiturient-office";
$arDirProperties = Array(

);
?>