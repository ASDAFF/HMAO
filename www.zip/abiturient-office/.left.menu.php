<?
$aMenuLinks = Array(
	Array(
		"Мой профиль", 
		"/abiturient-office/user-profile.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Подать заявление на поступление", 
		"/edu-organizations/apply.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Мои заявки", 
		"/abiturient-office/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Выход", 
		"/?logout=yes", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"test", 
		"/abiturient-office/test.php", 
		Array(), 
		Array(), 
		"" 
	)
);
?>