<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("abiturient-office");
?><?$APPLICATION->IncludeComponent(
	"spo.abiturient-office:main",
	"",
	Array(
		"IBLOCK_TYPE" => "-",
		"IBLOCK_ID" => "0",
		"SHOW_NAV" => "N",
		"COUNT" => "5",
		"SORT_FIELD1" => "ID",
		"SORT_DIRECTION1" => "ASC",
		"SORT_FIELD2" => "ID",
		"SORT_DIRECTION2" => "ASC",
		"SEF_MODE" => "Y",
		"CACHE_TYPE" => "A",
		"CACHE_TIME" => "3600",
		"SEF_FOLDER" => "/abiturient-office/",
		"SEF_URL_TEMPLATES" => Array("applicationList"=>"index.php","applicationEdit"=>"edit/#APPLICATION_ID#/"),
		"VARIABLE_ALIASES" => Array("applicationList"=>Array(),"applicationEdit"=>Array(),),
		"VARIABLE_ALIASES" => Array(
			"applicationList" => Array(),
			"applicationEdit" => Array(),
		)
	)
);?><?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>