<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Статистические отчёты");
?>Старница "Статистические отчёты"<br><?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>