<?
$aMenuLinks = Array(
	Array(
		"Список специальностей", 
		"/edu-organizations", 
		Array(), 
		Array(), 
		"" 
	)
);
?>