<?
$sSectionName = "Специальности";
$arDirProperties = Array(

);
?>