<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Специальности");
?>Главная страница раздела "Специальности". <br>
Неясно, нужны ли ещё старницы ("Поиск " и др.) для данного раздела.<br>
<br>
Можно на одной странице сделать и список, и поиск.<br><?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>