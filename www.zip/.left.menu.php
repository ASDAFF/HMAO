<?
$aMenuLinks = Array(
	Array(
		"Общая информация", 
		"/index.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Органы управления образованием", 
		"/organy-upravleniya-obrazovaniem.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Статистические отчёты", 
		"/statisticheskie-otchyety.php", 
		Array(), 
		Array(), 
		"" 
	),
);
?>