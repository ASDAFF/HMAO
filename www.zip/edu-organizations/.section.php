<?
$sSectionName = "Образовательные организации";
$arDirProperties = Array(

);
?>