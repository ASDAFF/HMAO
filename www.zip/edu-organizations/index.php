<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Список ОО");
?>Индексная страница раздела "Образовательные организации" - Она же "Список ОО"<br><?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>