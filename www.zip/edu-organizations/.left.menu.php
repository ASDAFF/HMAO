<?
$aMenuLinks = Array(
	Array(
		"Список ОО", 
		"/edu-organizations", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Подать заявление", 
		"/edu-organizations/apply.php", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Поиск ОО", 
		"/edu-organizations/search.php", 
		Array(), 
		Array(), 
		"" 
	)
);
?>