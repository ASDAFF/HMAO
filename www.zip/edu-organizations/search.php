<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Поиск ОО");
?>Страница поиск ОО по заданым параметрам. Опять же неизвестно, нужна ли тут эта страница, или ограничиться фильтром в "списке ОО"<br><?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>